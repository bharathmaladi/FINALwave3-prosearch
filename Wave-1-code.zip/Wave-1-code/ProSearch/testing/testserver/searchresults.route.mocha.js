var supertest = require("supertest");
var should = require("should");

var server = supertest.agent("http://localhost:8080");

describe("Testing",function(){
  it("should return filters api",function(done){
    server
    .get("/api/filters")
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });

  it("should return skills",function(done){
    var name="angular";
    server
    .get("/api/autoCompleteSkill/"+name)
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });

  it("should return locations",function(done){
    var name="Bath";
    server
    .get("/api/autoCompleteLocation/"+name)
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });

  it("should return profiles",function(done){
    var name="Rivers";
    server
    .get("/api/profiles/"+name)
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });
});
