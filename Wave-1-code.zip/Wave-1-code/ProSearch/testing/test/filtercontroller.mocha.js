describe('filterCtrl',function(){
  beforeEach(module('ProSearch'));

  var $controller,$service,filterService,$httpBackend;
	beforeEach(inject(function(_$controller_,filter,_$httpBackend_){
		$controller = _$controller_;
    filterService = filter;
    $httpBackend = _$httpBackend_;
    $httpBackend.whenGET('/api/filters').respond([
      {
        "id": 1,
        "searchType":"normal",
        "filterList":[
          {
            "id": 1,
            "type": "experience",
            "values": [
              "0-1",
              "1-2",
              "2-3",
              "3-4",
              "4-5",
              ">5"
            ]
          },
          {
            "id": 2,
            "type": "designation"
          },
          {
            "id": 3,
            "type": "skills"
          },
          {
            "id": 4,
            "type": "locations"
          },
          {
            "id": 5,
            "type": "role",
            "values": [
              "Developer",
              "Tester",
              "Designer",
              "Coder",
              "Analyst"
            ]
          },
          {
            "id": 6,
            "type": "rating",
            "values": [
              "more than 4",
              "more than 5",
              "more than 6",
              "more than 7",
              "more than 8"
            ]
          }
        ]

      },
      {
        "id":2,
        "searchType": "smart",
        "filterList": [
          {
            "id": 1,
            "type": "experience",
            "values": [
              "Atlest 6 months",
              "Atlest 1 year",
              "Atlest 2 year",
              "Between 2-5 year",
              "More than 5 years"
            ]
          },
          {
            "id": 2,
            "type": "department",
            "values": [
              "IT Solutions",
              "Finances",
              "Management",
              "Human Resourses"
            ]
          }
        ]
      }
    ]
);
	}));

  describe('$scope filters',function(){
    it('read and sets the filter for a specific catagory choosen',function(){
      // this.timeout(5000);
      var $scope={};
      $httpBackend.expectGET('/api/filters');
      var controller = $controller('filterCtrl',{$scope:$scope,filter:filterService});
      $httpBackend.flush();
      // var service=$service('filter',{$scope:$scope});
      console.log($scope.filters);
      expect($scope.filters).to.not.be.null;


    });

  });
});
