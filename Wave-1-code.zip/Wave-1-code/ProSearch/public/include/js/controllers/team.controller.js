angular.module('ProSearch')
  .controller('teamCtrl', ['$http', 'team', '$scope','$mdSidenav', '$mdDialog','$window','$rootScope', function($http, team, $scope,$mdSidenav, $mdDialog,$window,$rootScope) {
    $scope.onClickMenu = function() {
      $mdSidenav('left').toggle();
    };

    //authentication part. token should be present everywhere
    var token = $window.localStorage["authToken"];
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace('-', '+').replace('_', '/');
    $rootScope.loggedInUser = $window.atob(base64);
    $rootScope.email=JSON.parse($rootScope.loggedInUser).email;
    $rootScope.userName=JSON.parse($rootScope.loggedInUser).userName;
    $rootScope.userId=JSON.parse($rootScope.loggedInUser).user_id;


    //List all the teams created by the user.
   $scope.teams = [];
   team.getTeams($rootScope.userId).success(function mySucces(teams) {
     $scope.teams = teams;
     var btn_next = document.getElementById("pagination");
     btn_next.style.visibility = "hidden";
     var btn_next11= document.getElementById("pagination1");
     btn_next11.style.visibility = "hidden";
   });


    //Listing Profiles based on a team.
   $scope.listProfiles = function(teamName, teamId) {
     $scope.teamName = teamName;
     $scope.teamId = teamId;
     $rootScope.profiles = [];
     team.getProfiles($rootScope.userId).success(function(profiles) {
       for(var i=0;i<profiles.length;i++)
       {
         if(profiles[i]._id == teamId)
         {
           for(var j=0;j<profiles[i].teamMembers.length;j++)
           {
             $rootScope.profiles.push(profiles[i].teamMembers[j]);
           }
         }
       }
       $scope.changePage(1);
     });

   };

    //Adds a new Team.
    $scope.addTeam = function(event) {
      //Dialog box
      $mdDialog.show({
        templateUrl: 'views/addTeamDialog.html',
        targetEvent: event,
        controller: data,
        scope: $scope
      })
    };

    function data($scope, $mdDialog) {
      $scope.hide = function() {
        $mdDialog.hide();
      };
      $scope.cancel = function() {
        $mdDialog.cancel();
      };
      $scope.saveData = function() {
        var newTeamDetails = {};
        newTeamDetails["name"] = $scope.Name;
        newTeamDetails["description"] = $scope.Description;
        newTeamDetails["teamMembers"] = [];
        if($scope.Name != undefined)
        {
          $scope.teams.push(newTeamDetails);
          team.addTeam(newTeamDetails,$rootScope.userId);
        }
        else {
          alert("Please enter the Team Name");
        }

        $mdDialog.hide();
      };
    }

    //adding the team using "enter" key instead of the button
    $scope.enterKeyPress=function($event){
       var keyCode = $event.which || $event.keyCode;
       if (keyCode === 13) {
         var newTeamDetails = {};
         newTeamDetails["name"] = $scope.Name;
         newTeamDetails["description"] = $scope.Description;
         newTeamDetails["teamMembers"] = [];
         if($scope.Name != undefined)
         {
           $scope.teams.push(newTeamDetails);
           team.addTeam(newTeamDetails,$rootScope.userId);
         }
         else {
           alert("Please enter the Team Name");
         }

         $mdDialog.hide();
            }
         }

    //For removing the team
    $scope.removeTeam = function(event,teamId,teamName) {
      //Confirm Dialog box
      var confirm = $mdDialog.confirm()
        .title('Would you like to remove Team?')
        .targetEvent(event)
        .ok('Confirm')
        .cancel('Nope');
      $mdDialog.show(confirm).then(function() {
          //Calling service to get the team details to push the whole object into archive list
            profiles=$scope.teams;
            //Pushing the archiveTeam object into list.json
            for(var i=0;i<profiles.length;i++)
            {
              if(profiles[i]._id == teamId)
              {
                team.archiveTeam($rootScope.userId,profiles[i]);
              }
            }

          for (var i = 0; i < $scope.teams.length; i++) {
            if ($scope.teams[i].name == teamName) {
              var index = i;
            }
          }
          $scope.teams.splice(index, 1);
          //calling service to remove the team based on teamid
          team.removeTeam($rootScope.userId,teamId).success(function(response) {
            alert('Team has been Removed.');
          });
        },
        function() {
          alert('Team has not been Removed.');
        });
    };

    //Rename Team.
    $scope.renameTeam = function(event,teamId,teamName) {
      $scope.teamId = teamId;
      team.getProfiles($rootScope.userId).success(function(profiles) {
        for(var i=0;i<profiles.length;i++)
        {
          if(profiles[i]._id == teamId)
          {
            $scope.content = profiles[i];
          }
        }
        //Dialog box
        $mdDialog.show({
          templateUrl: 'views/editTeamDialog.html',
          targetEvent: event,
          scope: $scope,
          local: {
            key: $scope.content
          },
          controller: update
        })
      });
      //To update the team name and team description
      function update($scope, $mdDialog) {
        $scope.hide = function() {
          $mdDialog.hide();
        };
        $scope.cancel = function() {
          $mdDialog.cancel();
        };
        $scope.updateTeam = function() {
          var UpdatedTeamDetails = {};
          UpdatedTeamDetails["name"] = $scope.Name;
          UpdatedTeamDetails["description"] = $scope.Description;


          for (var i = 0; i < $scope.teams.length; i++) {
            if ($scope.teams[i].name == teamName) {
              var index = i;
            }
          }
          $scope.teams[index].name = $scope.Name;
          $scope.teams[index].description = $scope.Description;
          team.editTeam(UpdatedTeamDetails, $scope.teamId,$rootScope.userId);
          $mdDialog.hide();
        };
      }
    };

    //This will list all the teams with archive teams
    $scope.archiveTeams = [];
    $scope.viewAll = function() {
      //Getting all the teams removed by the user.
      team.getArchiveTeams($rootScope.userId).success(function mySucces(archiveTeams) {
        $scope.archiveTeams = archiveTeams;
      });
    };

    //Listing archive Profiles based on a teamid.
    $scope.listArchiveProfiles = function(teamName, teamId) {
      $scope.teamName = teamName;
      $scope.teamId = teamId;
      $scope.profiles = [];
      team.getArchiveProfiles(teamId).success(function(profiles) {
        $scope.profiles = profiles.Team_Members;
      });
    };

    //Undo the team based on teamId
    $scope.undo = function(teamId) {
      team.getArchiveTeams($rootScope.userId).success(function(profiles) {
        for(var i=0;i<profiles.length;i++)
        {
          if(profiles[i]._id == teamId)
          {
              $scope.teams.push(profiles[i]);
            team.addTeam(profiles[i],$rootScope.userId);
          }
        }

        for (var i = 0; i < $scope.archiveTeams.length; i++) {
          if ($scope.archiveTeams[i]._id == teamId) {
            var index = i;
          }
        }
        $scope.archiveTeams.splice(index, 1);
        team.removeArchiveTeam($rootScope.userId,teamId);

      });
    };

    $scope.logout = function(event) {
      $window.localStorage.removeItem("authToken");
      $window.location.href="/login.html";
    };

    // Pagination code

   $scope.current_page = 1;
   $scope.records_per_page = 5;


   $scope.prevPage = function()
   {

     if ($scope.current_page > 1) {
       $scope.current_page--;
       $scope.changePage($scope.current_page);
     }
   }
   $scope.nextPage = function()
   {

     if ($scope.current_page < $scope.numPages()) {
       $scope.current_page++;
       $scope.changePage($scope.current_page);
     }
   }


$scope.changePage = function(page) {
     $scope.data = [];
     var btn_next = document.getElementById("btn_next");
     var btn_prev = document.getElementById("btn_prev");
     var listing_table = document.getElementById("listingTable");
     var page_span = document.getElementById("page");
     page_span.style.visibility = "visible";

     var btn_next1 = document.getElementById("btn_next1");
     var btn_prev1 = document.getElementById("btn_prev1");
     var listing_table1 = document.getElementById("listingTable1");
     var page_span1 = document.getElementById("page1");
     page_span1.style.visibility = "visible";

     // Validate page
     if (page < 1) page = 1;
     if (page > $scope.numPages()) page = $scope.numPages();



     for (var i = (page - 1) * $scope.records_per_page; i < (page * $scope.records_per_page) && i < $rootScope.profiles.length; i++) {
       // check whether the "profiles" is key or not
       $rootScope.profiles[i].forEach(function(profile){
         $scope.data.push(profile);
       })
     }
     page_span.innerHTML = page + "/" + $scope.numPages();
     page_span1.innerHTML = page + "/" + $scope.numPages();
     if (page == 1) {
       btn_prev.style.visibility = "hidden";
       btn_prev1.style.visibility = "hidden";
     } else {
       btn_prev.style.visibility = "visible";
       btn_prev1.style.visibility = "visible";
     }

     if (page == $scope.numPages()) {
       btn_next.style.visibility = "hidden";
       btn_next1.style.visibility = "hidden";
     } else {
       btn_next.style.visibility = "visible";
       btn_next1.style.visibility = "visible";
     }
   }

   $scope.numPages = function() {
     return Math.ceil($rootScope.profiles.length / $scope.records_per_page);
   }


  }]);
