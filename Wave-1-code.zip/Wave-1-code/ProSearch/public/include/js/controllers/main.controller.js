angular.module('ProSearch')
  .controller('mainCtrl', ['$scope', '$q', '$filter','$http', '$mdDialog', '$window', '$rootScope', function($scope, $q,$filter, $http, $mdDialog, $window, $rootScope) {

    $scope.searchTerm = "";
    $scope.searchResult = [];

    // assigning the created token value to the variable "token"
    var token = $window.localStorage["authToken"];
    var base64Url = token.split('.')[1];
    var base64 = base64Url.replace('-', '+').replace('_', '/');
    $rootScope.loggedInUser = $window.atob(base64);
    $rootScope.email = JSON.parse($rootScope.loggedInUser).email;
    $rootScope.userName = JSON.parse($rootScope.loggedInUser).userName;
    $rootScope.userId = JSON.parse($rootScope.loggedInUser).user_id;

    //Smart search part
    $scope.smartSearch = [];
    //Calling the smart search API
    $http.get('/api/smartSearch').then(function(response) {
      for (var i = 0; i < response.data.length; i++) {
        $scope.smartSearch.push(response.data[i]);
      }
    });

    // counting how many times the smartSearch link has been clicked
    $scope.check = function (id,usedCount,lastUsed) {
          var obj={};
          obj["usedCount"]=parseInt(usedCount)+1;
          var curDate=new Date();
          curDate  = $filter('date')(curDate, "dd-MM-yyyy");
          curDate=curDate.toString();
          obj["lastUsed"]=curDate;
          $http.patch("/api/smartSearch/"+id,obj);
              }
    //Saved search part
    $scope.savedSearch = [];
    //Calling the saved search API
    $http.get('/api/savedSearch/' + $rootScope.userId).then(function(response) {
      $scope.savedSearch = response.data;
    });

    // removing the saved search by the user
    $scope.removeSavedSearch = function(event, savedSearchId) {
      var confirm = $mdDialog.confirm()
        .title('Would you like to remove Search?')
        .targetEvent(event)
        .ok('Confirm')
        .cancel('Nope');
      $mdDialog.show(confirm).then(function() {
          //Calling the API to delete the saved search
          $http.delete('/api/savedSearch/' + $rootScope.userId + '/' + savedSearchId);
        },
        function() {
          alert('Team has not been Removed.');
        });
    };

    // logout button destroys the session by removing the token and redirecting to login page
    $scope.logout = function(event) {
      $window.localStorage.removeItem("authToken");
      $window.location.href = "/login.html";
    };

    //
    // function data($scope, $mdDialog) {
    //   $scope.hide = function() {
    //     $mdDialog.hide();
    //   };
    //   $scope.cancel = function() {
    //     $mdDialog.cancel();
    //   };
    //
    // }
    // $scope.signUp = function(event) {
    //   //Dialog box
    //   $mdDialog.show({
    //     templateUrl: 'views/signUp.html',
    //     targetEvent: event,
    //     controller: data,
    //     scope: $scope
    //   })
    // };
  }]);
