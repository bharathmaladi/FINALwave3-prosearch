angular.module("ProSearch")
  .controller("bot", function($scope) {
    $scope.questions = [{
      "question": "What do you mean MVC?",
      "answer": ""
    }, {
      "question": "Frameworks or Libraries which uses MVC?",
      "answer": ""
    }, {
      "question": "Are you searching for a Front End Developer",
      "answer": ""
    }, {
      "question": "Are you searching for a backend Developer?",
      "answer": ""
    }];

    $scope.questionsToBeAsked = [];

    $scope.questionsToBeAsked.push($scope.questions[0]);

    $scope.onNext = function() {

    };

  });
