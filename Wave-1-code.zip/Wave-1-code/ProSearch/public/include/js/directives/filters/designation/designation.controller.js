angular.module('ProSearch')
  .controller('designationCtrl', ['$q', '$scope', 'autoComplete', function($q, $scope, autoComplete) {
    "use strict";
    $scope.searchDesignation = "";
    $scope.isDisabled = false;
    $scope.noCache = false;

    $scope.searchDesignation = function(searchText) {
      return autoComplete.getDesignation(searchText).then(function(response) {
        var designations = [];
        for (var i = 0; i < response.data.records.length; i++) {
          designations.push(response.data.records[i]._fields[0]);
        }
        return designations;
      });
    }

  }]);
