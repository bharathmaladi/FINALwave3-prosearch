angular.module('ProSearch')
  .directive('experience', function() {
    return {
      templateUrl: 'include/js/directives/filters/experience/experience.tmpl.html',
      scope: {
        type: '<',
        values: '<'
      },
      controller: "experienceCtrl"
    }
  })
