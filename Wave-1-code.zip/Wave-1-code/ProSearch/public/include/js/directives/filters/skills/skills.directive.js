angular.module('ProSearch')
  .directive('skills', function() {
    return {
      templateUrl: 'include/js/directives/filters/skills/skills.tmpl.html',
      scope: {
        type: '<'
      },
      //defining controller for autocomplete
      controller: "skillsCtrl"
    }
  });
