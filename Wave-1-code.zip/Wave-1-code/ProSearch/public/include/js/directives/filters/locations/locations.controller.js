angular.module('ProSearch')
  .controller('locationCtrl', ['$http', '$q', '$rootScope', '$scope', 'autoComplete', function($http, $q, $rootScope, $scope, autoComplete) {
    "use strict";
    $scope.searchLocation = "";
    $scope.isDisabled = false;
    $scope.noCache = false;
    $scope.selectedItemChange = function(item) {
      var selectedLocation = $scope.selectedLocation;
      $rootScope.searchResult = [];
      $rootScope.searchTerm = $rootScope.searchTerm + " in " + selectedLocation;
      $http.get("/api/profiles/" + $rootScope.searchTerm).then(function(response) {
        $rootScope.selectedPersons = $rootScope.searchResult.length;
      });


    }

    $scope.searchLocation = function(searchText) {
      return autoComplete.getLocation(searchText).then(function(response) {
        var location = [];
        for (var i = 0; i < response.data.records.length; i++) {
          location.push(response.data.records[i]._fields[0]);
        }
        return location;
      });
    }

  }]);
