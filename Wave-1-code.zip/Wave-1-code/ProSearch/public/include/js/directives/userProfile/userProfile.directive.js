angular.module('ProSearch')
  .directive('userProfile', function() {
    return {
      templateUrl: 'include/js/directives/userProfile/userProfile.view.html',
      scope: {
        profile: '<',
        onProfileToggle: '&'
      },
      controller: function($scope) {
        $scope.viewDetails = false;
        $scope.viewMore = function() {
          if ($scope.viewDetails)
            $scope.viewDetails = false;
          else
            $scope.viewDetails = true;
        }
      }
    }
  })
