var nlp = require('nlp_compromise');
var async = require('async');
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.98", neo4j.auth.basic('neo4j', 'password'));
var session = driver.session();
var skills = require('../db/dictionary/skills.json');
var location = require('../db/dictionary/location.json');
var qualification = require('../db/dictionary/qualification.json');
var roles = require('../db/dictionary/roles.json');
var companies = require('../db/dictionary/companies.json');

//parses the individual terms to the lexicon format. Ex. {"angularjs":"skills"}
var lexiconParse = function(term, tag) {
  var lexicon = {};
  var normalizedTerm = nlp.term(term).normalize();
  lexicon["type"] = tag;
  lexicon["term"] = normalizedTerm;
  return lexicon;
};

//array of dictionary
var dictionaries = [{
  terms: location,
  type: "location"
}, {
  terms: skills,
  type: "skills"
}, {
  terms: qualification,
  type: "qualification"
}, {
  terms: roles,
  type: "roles"
}, {
  terms: companies,
  type: "organization"
}];

//Generates a lexicon parser function for all the dictionaries.
var lexiconMapper = dictionaries.map(function(dictionary) {
  return function(callback) {
    var lexiconDictionary = dictionary.terms.map(function(location) {
      return lexiconParse(location, dictionary.type);
    });
    callback(null, lexiconDictionary);
  };
});

//Converts all the terms into their equivalent lexicons in parallel.
async.parallel(lexiconMapper, function(err, results) {
  // mongoUtil.getConnection("mongodb://localhost:27017/Portfolio-Management", function(err,db) {
  results.forEach(function(dictionary) {
    dictionary.forEach(function(lexicon) {
      var query = "MERGE (term:" + lexicon.type + " {term: {termParam}}) return term";
      session.run(query, {
        termParam: lexicon.term
      }).then(function(record) {
        console.log(record);
      }).catch(function(err) {
        console.log(err);
      });
    });
  });
  // });
});
