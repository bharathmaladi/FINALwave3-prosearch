var express = require('express');
var router = express.Router();
var mongoUtil = require('../db/mongoUtil');
var getEssentialTerms = require("./termExtraction.js");
var getProfiles = require("./search.js");
var ObjectId = require("mongodb").ObjectID;
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.98", neo4j.auth.basic('neo4j', 'password'));
var session = driver.session();

router.get('/profiles/:searchTerm?', function(req, res) {
  var db = mongoUtil.getDb();
  var searchTerm = req.params.searchTerm;
  var userProfiles = [];
  var promises = [];
  getEssentialTerms(searchTerm).then(function(extractedTerm) {
    getProfiles(extractedTerm).then(function(profiles) {
      // console.log(profiles);
      profiles.records.forEach(function(record) {
        var promise = new Promise(function(resolve, reject) {
              console.log(record._fields[0].properties.id);
          db.collection('portfolio_cache').find({
            "_id": ObjectId(record._fields[0].properties.id)
          }).toArray(function(err, docs) {
            if (err) {
              handleError(res, err.message, "Failed to get contacts.");
              reject();
            } else {
              userProfiles.push(docs[0]);
              resolve();
            }
          });
        });
        promises.push(promise);
      });
      Promise.all(promises).then(function() {
        res.json(userProfiles);
      });
    },function(err) {console.log(err);});
  });
});


router.get('/filters', function(req, res) {
  var db = mongoUtil.getDb();
  db.collection('filters').find({}).toArray(function(err, docs) {
    if (err) {
      handleError(res, err.message, "Failed to get contacts.");
    } else {
      res.status(200).json(docs);
    }
  });
});


router.get('/autoCompleteSkill/:skill?', function(req, res) {
  var term = req.params.skill.toLowerCase();
  var query = "MATCH (skill:skills) WHERE skill.term STARTS WITH \"" + term + "\" return skill.term"
  session.run(query).then(function(records) {
    res.send(records);
  }).catch(function(err) {
    console.log(err);
  });
});

router.get('/autoCompleteDesignation/:designation?', function(req, res) {
  var term = req.params.designation.toLowerCase();
  var query = "MATCH (role:roles) WHERE role.term STARTS WITH \"" + term + "\" return role.term"
  session.run(query).then(function(records) {
    res.send(records);
  }).catch(function(err) {
    console.log(err);
  });
});
router.get('/autoCompleteLocation/:location?', function(req, res) {
  var term = req.params.location.toLowerCase();
  var query = "MATCH (location:location) WHERE location.term STARTS WITH \"" + term + "\" return location.term"
  session.run(query).then(function(records) {
    res.send(records);
  }).catch(function(err) {
    console.log(err);
  });
});

module.exports = router;
