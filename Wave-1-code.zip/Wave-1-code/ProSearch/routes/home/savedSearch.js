var express = require('express');
var router = express.Router();
var mongoUtil = require('../../db/mongoUtil');
var ObjectId = require('mongodb').ObjectID;
router.get('/savedSearch/:userId?', function(req, res) {
  var db = mongoUtil.getDb();
  db.collection('users').find({
    "_id": ObjectId(req.params.userId)
  }).toArray(function(err, docs) {
    if (err) {
      handleError(res, err.message, "Failed to get contacts.");
    } else {

      res.status(200).json(docs[0].savedSearch);
    }
  });
});

router.delete('/savedSearch/:userId/:id?', function(req, res) {
  var removeSavedId = req.param('id');
  var db = mongoUtil.getDb();
  db.collection('users').update({
    "_id": ObjectId(req.params.userId)
  }, {
    $pull: {
      "savedSearch": {
        "_id": ObjectId(req.params.id)
      }
    }
  }, function(err, result) {
    if (err) {
      handleError(res, err.message, "Failed to delete saved search");
    } else {
      res.status(204).end();
    }
  });
});

router.post('/savedSearch/:userId?', function(req, res) {
  var object = req.body;
  object["_id"] = new ObjectId();
  var db = mongoUtil.getDb();
  db.collection('users').update({
    "_id": ObjectId(req.params.userId)
  }, {
    $push: {
      "savedSearch":object
    }
  }, function(err, doc) {
    if (err) {
      handleError(res, err.message, "Failed to create new contact.");
    } else {
      res.status(201).json(doc);
    }
  });
});

module.exports = router;
