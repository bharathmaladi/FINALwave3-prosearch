var express = require('express');
var router = express.Router();
var mongoUtil = require('../../db/mongoUtil');

router.get('/smartSearch', function(req, res) {
  var db = mongoUtil.getDb();
  db.collection('smartSearch').find({}).toArray(function(err, docs) {
    if (err) {
      handleError(res, err.message, "Failed to get contacts.");
    } else {
      res.status(200).json(docs);
    }
  });
});

router.patch('/smartSearch/:Id?', function(req, res) {
 var object = req.body;
 var db = mongoUtil.getDb();
 db.collection('smartSearch').update({
   "_id": parseInt(req.params.Id)
 }, {
   $set: {
     'usedCount':object.usedCount,
     'lastUsed':object.lastUsed
   }
 }, function(err, result) {
   if (err) {
     handleError(res, err.message, "Failed to delete contact");
   } else {
     res.status(204).end();
   }
 });
});
module.exports = router;
