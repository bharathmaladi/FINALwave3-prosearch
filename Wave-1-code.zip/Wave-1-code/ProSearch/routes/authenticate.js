var express = require('express');
var router = express.Router();
var mongoUtil = require('../db/mongoUtil');
var jwt = require('jsonwebtoken');
var path = require('path');

router.post('/authenticate', function(req, res) {
  var object = req.body;
  var db = mongoUtil.getDb();
  db.collection('users').find({
    email: req.body.email,
    password: req.body.password
  }).toArray(function(err, doc) {
    if (err) {
      handleError(res, err.message, "Failed.");
    } else {
      if (doc.length > 0) {
        var token = jwt.sign({
          userName: doc[0].username,
          user_id: doc[0]._id,
          email: doc[0].email
        }, "portal", {
          expiresIn: 86400
        });
        res.status(201).json({
          "token": token
        });
      } else {
        res.status(403).send();
      }
    }
  });
});

router.use(function(req, res, next) {
  // check header or url parameters or post parameters for token
  var token = req.headers['x-access-token'];
  // decode token
  if (token) {
    // verifies secret and checks exp
    jwt.verify(token, 'portal', function(err, decoded) {
      if (err) {
        return res.json({
          success: false,
          message: 'Failed to authenticate token.'
        });
      } else {
        // if everything is good, save to request for use in other routes
        req.decoded = decoded;
        next();
      }
    });

  } else {
    // if there is no token
    // return an error
    return res.status(403).send({
      success: false,
      message: 'No token provided.'
    });

  }
});

module.exports = router;
