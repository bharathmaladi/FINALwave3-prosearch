var highland = require("highland");
var mongoUtil = require("../db/mongoUtil");
var getTags = require('./getTags');
var _ = require('underscore');
var nlp = require('nlp_compromise');

var getEssentialTerms = function(searchText) {
  var terms = [];
  searchText = nlp.sentence(searchText).normal();
  var db = mongoUtil.getDb();
  return new Promise(function(resolve, reject) {
    var lexiconStream = db.collection("lexicons").find({}).stream();
    lexiconStream.on("end", function() {
      resolve(terms);
    });
    highland("data", lexiconStream)
      .map(function(lexicon) {
        var lexicon = _.omit(lexicon, '_id', 'location', 'organization', 'skills', 'roles', 'qualification');
        var tag = getTags(searchText, lexicon);
        if (tag !== undefined) {
          return tag
        };
      }).each(function(d) {
        if (d !== undefined) {
          terms.push(d);
        }
      });
  });
};

module.exports = getEssentialTerms;
