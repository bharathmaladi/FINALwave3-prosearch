var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.98", neo4j.auth.basic('neo4j', 'password'));
var session = driver.session();
var _ = require('underscore');

var getProfiles = function(terms) {
  var skillCollection = "";
  var locationCollection = "";
  terms.forEach(function(term,index,arr) {
    if(term[_.keys(term)] == "skills") {
      skillCollection += '"'+_.keys(term)+'",';
    } if(term[_.keys(term)] == "location") {
      locationCollection += '"'+_.keys(term)+'",';
    }
  });
  if(locationCollection != "")
  locationCollection = "[" + locationCollection.replace(/,\s*$/, "") + "]";
  if(skillCollection != "")
  skillCollection = "[" + skillCollection.replace(/,\s*$/, "") + "]";
  if(locationCollection != "")
  var query = "MATCH (user:Profile)-[r]-(term:skills) where term.term in "+skillCollection+" WITH user,SUM(toInt(r.intensity)) as index,collect(DISTINCT term) as terms where length(terms) = length("+skillCollection+") WITH user,index MATCH (user)-[r]-(loc:location) where loc.term in " + locationCollection+" return DISTINCT user, index order by index DESC";
  else {
    var query ="MATCH (user:Profile)-[r]-(term:skills) where term.term in "+skillCollection+" WITH user,SUM(toInt(r.intensity)) as index,collect(DISTINCT term) as terms where length(terms) = length("+skillCollection+") return DISTINCT user,index";
  }
  console.log(query);
  return session.run(query);
}

module.exports = getProfiles;
