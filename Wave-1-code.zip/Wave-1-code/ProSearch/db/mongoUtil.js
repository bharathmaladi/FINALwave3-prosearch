var MongoClient = require('mongodb').MongoClient;

var _db;
var ObjectID = MongoClient.ObjectID;
module.exports = {
  connectToServer: function(callback) {  
    MongoClient.connect("mongodb://10.219.85.96:27017/Portfolio-Management", function(err, db) {   
      _db = db;   
      return callback(err);  
    }); 
  },
  getDb: function() {  
    return _db;   // console.log(_db);
  }
};
