var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var logger = require('morgan');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
/*load all the api's */
var register = require('./routes/register');
var authenticate = require('./routes/authenticate');
var routesSavedSearch = require('./routes/home/savedSearch');
var routesSmartSearch = require('./routes/home/smartSearch');
var teams = require('./routes/team.routes.js');
var archiveTeams = require('./routes/archive.routes.js');
var profiles = require('./routes/profiles.routes.js');

var app = express();
/*for singleton connection*/
var mongoUtil = require('./db/mongoUtil');

mongoUtil.connectToServer(function(err) {
  // start the rest of your app here
   
  app.use(logger('dev')); 
  app.use(bodyParser.json()); 
  app.use(bodyParser.urlencoded({
    extended: false
  })); 
  app.use(cookieParser()); 
  app.use(express.static(path.join(__dirname, 'public')));

  app.use('/api', register);
  app.use('/api', authenticate);
  app.use('/api', routesSavedSearch); 
  app.use('/api', routesSmartSearch); 
  app.use('/api', teams);
  app.use('/api', archiveTeams); 
  app.use('/api', profiles);



    // catch 404 and forward to error handler
   
  app.use(function(req, res, next) {  
    var err = new Error('Not Found');  
    err.status = 404;  
    next(err); 
  });

   
  if (app.get('env') === 'development') {  
    app.use(function(err, req, res, next) {   
      res.status(err.status || 500);   
      res.render('error', {    
        message: err.message,
            error: err   
      });  
    }); 
  }

   
  app.use(function(err, req, res, next) {  
    res.status(err.status || 500);
    console.log(err.message); 
  });
});

module.exports = app;
