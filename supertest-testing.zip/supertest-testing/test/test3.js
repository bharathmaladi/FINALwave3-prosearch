var supertest = require("supertest");
var should = require("should");
var app = require("../server2");

// UNIT test begin

describe("SAMPLE unit test3",function(){

  // #1 should return home page
  it("should return home page without running server",function(done){

    // calling home page api
    supertest(app)
    .get("/")
    //.expect("Content-type",/json/)
    .expect(200) // This is HTTP response
    .end(function(err,res){
      // HTTP status should be 200
      res.status.should.equal(200);
      // Error key should be false.
      res.body.message.should.equal("Hello! The API is at http://localhost:8080/api");
      console.log(res.body);
      done();
    });
  });



  // #1 should return home page
  it("should check invalid user name",function(done){

    // calling home page api
    supertest(app)
    .post("/api/authenticate")
    .send({name: 'Nicki', password: 'password'})
    .expect("Content-type",/json/)
    .expect(200) // This is HTTP response
    .end(function(err,res){
      // HTTP status should be 200
      res.status.should.equal(200);
      // Error key should be false.
      res.body.message.should.equal('Authentication failed. User not found.')
      done();
    });
  });


  // #1 should return home page
  it("should check correct user name with wrong password",function(done){

    // calling home page api
    supertest(app)
    .post("/api/authenticate")
    .send({name: 'Nick', password: 'passwordd'})
    .expect("Content-type",/json/)
    .expect(200) // This is HTTP response
    .end(function(err,res){
      // HTTP status should be 200
      res.status.should.equal(200);
      // Error key should be false.
      res.body.message.should.equal('Authentication failed. Wrong password.')
      done();
    });
  });



  // #1 should return home page
  it("should check correct user name with correct password",function(done){

    // calling home page api
    supertest(app)
    .post("/api/authenticate")
    .send({name: 'Nick', password: 'password'})
    .expect("Content-type",/json/)
    .expect(200) // This is HTTP response
    .end(function(err,res){
      // HTTP status should be 200
      res.status.should.equal(200);
      // Error key should be false.
      res.body.message.should.equal('Enjoy your token!')
      done();
    });
  });

});