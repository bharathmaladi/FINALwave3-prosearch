var supertest = require("supertest");
var should = require("should");
var app = require("../server");

// UNIT test begin

describe("SAMPLE unit test2",function(){

  // #1 should return home page
  it("should return home page without running server",function(done){

    // calling home page api
    supertest(app)
    .get("/")
    .expect("Content-type",/json/)
    .expect(200) // This is HTTP response
    .end(function(err,res){
      // HTTP status should be 200
      res.status.should.equal(200);
      // Error key should be false.
      res.body.error.should.equal(false);
      console.log(res.body);
      done();
    });
  });


  // #2 should post data to /add api
  it("should post data to /add api without running server",function(done){

    // calling /add api through post
    supertest(app)
    .post("/add")
    .send({num1 : 100, num2 : 200})
    .expect("Content-type",/json/)
    .expect(200) // This is HTTP response
    .end(function(err,res){
      // HTTP status should be 200
      res.status.should.equal(200);
      // Error key should be false.
      res.body.error.should.equal(false);
      console.log(res.body);
      done();
    });
  });


  // #3 should return 404 not found
  it("should return 404",function(done){
    supertest(app)
    .get("/random")
    .expect(404)
    .end(function(err,res){
      res.status.should.equal(404);
      done();
    });
  })



  // #4 should post data to /add api and validate the result
  it("should add two number",function(done){

    //calling ADD api
    supertest(app)
    .post('/add')
    .send({num1 : 100, num2 : 200})
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.status.should.equal(200);
      res.body.error.should.equal(false);
      res.body.data.should.equal(300);
      done();
    });
  });


});