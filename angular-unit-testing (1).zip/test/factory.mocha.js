describe('Person', function () {

var Person, visitor, $httpBackend;

beforeEach(module('myApp'));

beforeEach(module(function ($provide) {
  visitor = {};
  $provide.value('visitor', visitor);
}));

// ...
beforeEach(inject(function (_Person_, _$httpBackend_) {
  Person = _Person_;
  $httpBackend = _$httpBackend_;
}));

// ...

describe('#create', function () {

  it('creates the person on the server', function () {
    $httpBackend
    .when('POST', '/people')
    .respond(200, {name:"Benn"});

    var succeeded;
    new Person('Ben').create()
    .then(function (response) {

      console.log(response.data);

      if(response.data.name=="Benn")
        succeeded = true;
        else {
          succeeded=false;
        }
    });
    $httpBackend.flush();
    expect(succeeded).to.be.true;
  });

});

});
