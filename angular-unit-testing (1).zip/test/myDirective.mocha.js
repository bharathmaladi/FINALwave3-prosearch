describe('Welcome Directive', function () {

  var element, scope;

  beforeEach(module('myDirective'));

  beforeEach(inject(function ($compile, $rootScope) {
    scope = $rootScope.$new();
    element = $compile('<welcome person="DP"></welcome>')(scope);
    //element = '<welcome person="DP"></welcome>';
    //console.log(element);
  }));

  it('welcomes the person', function () {
    scope.DP = {
      greet: function () {
        return 'Hello!';
      }
    };
    scope.$digest();
    expect(element.find('span').text()).to.equal('Hello! Welcome to the app!');

    scope.DP = {
      greet: function () {
        return 'Hello2!';
      }
    };
    scope.$digest();

    //console.log(element);
    expect(element.find('span').text()).to.equal('Hello2! Welcome to the app!');
  });
});
