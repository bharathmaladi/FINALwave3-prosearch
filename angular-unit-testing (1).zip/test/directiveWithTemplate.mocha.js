describe('Testing directive having TemplateUrl', function () {

    var el, scope;

    beforeEach(module('docsIsolateScopeDirective'));
    beforeEach(module('view/my-customer.html'));

    beforeEach(inject(function ($rootScope, $compile) {

        el = angular.element('<my-customer info="naomi"></my-customer>');
        scope = $rootScope.$new();
        $compile(el)(scope);
        //console.log(el);
        scope.naomi = { name: 'Naomi', address: '1600 Amphitheatre' };
        scope.$digest();
        //console.log(el);
    }));

    it('Test Case - Testing directive having TemplateUrl', function () {
        //console.log(el);
        var data = el[0].children[0].innerHTML;
        expect(data).to.equal("Name: Naomi Address: 1600 Amphitheatre");

    });

});
