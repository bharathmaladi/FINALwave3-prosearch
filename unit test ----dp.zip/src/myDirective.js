angular.module('myDirective',[])
  .directive('welcome', function () {
    return {
      restrict: 'E',
      scope: {
        person: '='
      },
      template: '<span>{{person.greet()}} Welcome to the app!</span>'
    };
});
