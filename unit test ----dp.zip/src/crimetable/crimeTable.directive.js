angular.module('crimeTableModule',[])
.directive('crimeTable', function() {
  return {
    templateUrl:'CustomDirectives/crimeTable.template.html'
  };
});
