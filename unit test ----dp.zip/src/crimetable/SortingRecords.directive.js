angular.module('SortingRecordsModule',[])
.directive('sortRecords', function() {
  return {
    templateUrl:'CustomDirectives/SortingRecords.template.html'
  };
});
