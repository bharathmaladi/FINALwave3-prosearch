describe("Testing Dynamic Table With Angular.js",function(){

  beforeEach(module('Apptable'));

  var ctrl;
  var http;

  beforeEach(inject(function(_$controller_,_$httpBackend_) {
    ctrl = _$controller_;
    http = _$httpBackend_;
  }));


 // =============== To Get The Data From The Crime.json File ==============================

  var data=function() {
      http
      .when('GET', 'crime.json')
      .respond(200, [{"year":"2008","over":24141,"under":25397},
                    {"year":"2009","over":21503,"under":24216},
                    {"year":"2010","over":21851,"under":24633},
                    {"year":"2011","over":15668,"under":28994},
                    {"year":"2012","over":15979,"under":29526},
                    {"year":"2013","over":15615,"under":27899},
                    {"year":"2014","over":14954,"under":28842},
                    {"year":"2015","over":12652,"under":24629}]);
            http.flush();
  };


 // ============ Testing The Controller Functions =======================================================================

  describe('Crime Table Controller Functions', function() {

    var scp = {};

    // ================ Testing The Pagination Function =============================================

    it('Testing The Pagination',function(){
      var ctrl1 = ctrl('mainCtrl', { $scope:scp });
      data();
     console.log("No Of Records From Json is "+scp.crimes.length);
     console.log("No Of Pages "+total_pages);
     console.log("No Of Records Displayed Per Page is "+scp.pageSize);
    //  console.log(scp.restcrimes);
     scp.paging(2);
    //  console.log(scp.restcrimes);
     expect(total_pages).to.equal(2);
     expect(scp.restcrimes.length).to.equal(4);
    });

   // ================ Testing The DeleteData Function =============================================

    it('Should Delete A Record', function() {

      console.log("After Calling Data Function"+' '+scp.crimes.length);
      scp.DeleteData(2008);
      console.log("After Delete Function "+scp.crimes.length);
      expect(scp.crimes.length).to.equal(7);
      expect(scp.restcrimes.length).to.equal(3);
      console.log("No Of Records Displayed in Page-2 is "+scp.restcrimes.length);
    });

   // ================ Testing The AddData Function ===============================================

    it('Should Add A Record',function(){

    scp.add_year=2007;
    scp.add_over=2043;
    scp.add_under=2103;
    scp.AddData();
    console.log("After Adding Function "+scp.crimes.length);
    expect(scp.crimes.length).to.equal(8);
    expect(scp.restcrimes.length).to.equal(4);
    console.log("No Of Records Displayed in Page-2 is "+scp.restcrimes.length);

    // ================ Testing The Reset Functioanlity ===========================================

    scp.reset();
    expect(scp.add_year).to.equal('');
    expect(scp.add_over).to.equal('');
    expect(scp.add_under).to.equal('');
    console.log("------Reset Function Tested------")
    });

   // =============== Testing The Above Function =================================================

    it('Filtering Data',function(){
      console.log("Before Sorting using Year "+scp.crimes.length);

     // ============  Testing The Filter By Year Functionality ============================

      scp.propertyValue='year';
      scp.apply_constraint=2013;
      scp.Above();
      console.log("After Sorting using Year "+scp.crimes.length);

      expect(scp.crimes.length).to.equal(3);

      expect(total_pages).to.equal(1);
      console.log("No Of Pages "+total_pages);

      expect(scp.restcrimes.length).to.equal(3);
      console.log("No Of Records Displayed in Page-1 is "+scp.restcrimes.length);

    // ============= Testing The Filter By Over Functionality ===========================

      console.log("Before Sorting using Over "+scp.crimes.length);
      scp.propertyValue='over';
      scp.apply_constraint=15900;
      scp.Above();
      console.log("After Sorting using Over "+scp.crimes.length);
      expect(scp.crimes.length).to.equal(4);

      expect(total_pages).to.equal(1);
      console.log("No Of Pages "+total_pages);

      expect(scp.restcrimes.length).to.equal(4);
      console.log("No Of Records Displayed in Page-1 is "+scp.restcrimes.length);

    // ============= Testing The Filter By Under Functionality =========================

      console.log("Before Sorting using Under "+scp.crimes.length);
      scp.propertyValue='under';
      scp.apply_constraint=25900;
      scp.Above();
      console.log("After Sorting using Under "+scp.crimes.length);
      expect(scp.crimes.length).to.equal(5);

      expect(total_pages).to.equal(2);
      console.log("No Of Pages "+total_pages);

      expect(scp.restcrimes.length).to.equal(4);
      console.log("No Of Records Displayed in Page-1 is "+scp.restcrimes.length);

      //  =========== Testing The Next Functionality ====================================

      scp.next();
      expect(scp.restcrimes.length).to.equal(1);
      console.log("No Of Records Displayed in Page-2 is "+scp.restcrimes.length);
      console.log('------Next Function Tested-------');
     //  =========== Testing The Prev Functionality =====================================

      scp.prev();
      expect(scp.restcrimes.length).to.equal(4);
      console.log("No Of Records Displayed in Page-1 is "+scp.restcrimes.length);
      console.log('------Prev Function Tested---------');

    // ============ Testing The Filter By Null Value Functionality =====================

      console.log("Before Sorting With Null Value "+scp.crimes.length);
      scp.propertyValue='year';
      scp.apply_constraint=null;
      scp.Above();
      console.log("After Sorting With Null Value "+scp.crimes.length);
      expect(scp.crimes.length).to.equal(8);

      expect(total_pages).to.equal(2);
      console.log("No Of Pages "+total_pages);

      expect(scp.restcrimes.length).to.equal(4);
      console.log("No Of Records Displayed in Page-1 is "+scp.restcrimes.length)
    });


  });

});


describe("Testing The Filter For Number SubScript",function(){

 beforeEach(module('FilterModule'));

var filter;

 beforeEach(inject(function(_$filter_){

  filter=_$filter_;

 }));

  it('Filter Should Concatnate The Numbers With Subscript',function(){

   var Subscript=filter('NumSupScrpt');

   expect(Subscript(1)).to.equal('1st');
   expect(Subscript(2)).to.equal('2nd');
   expect(Subscript(3)).to.equal('3rd');
   expect(Subscript(4)).to.equal('4th');
   expect(Subscript(7)).to.equal('7th');


  });


});

describe("Testing The Directives In Dynamic Table ",function(){

  var compile;
  var rootScope;
  var template;
  var http;

  beforeEach(module('crimeTableModule','src/crimetable/crimeTable.template.html'));

  beforeEach(inject(function($templateCache,_$compile_,_$rootScope_,_$httpBackend_){

    template = $templateCache.get('src/crimetable/crimeTable.template.html');
		$templateCache.put('CustomDirectives/crimeTable.template.html',template);
		compile = _$compile_;
	  rootScope = _$rootScope_;
    http=_$httpBackend_;
  }));



    var data=function() {
        http
        .when('GET', 'crime.json')
        .respond(200, [{"year":"2008","over":24141,"under":25397},
                      {"year":"2009","over":21503,"under":24216},
                      {"year":"2010","over":21851,"under":24633},
                      {"year":"2011","over":15668,"under":28994},
                      {"year":"2012","over":15979,"under":29526},
                      {"year":"2013","over":15615,"under":27899},
                      {"year":"2014","over":14954,"under":28842},
                      {"year":"2015","over":12652,"under":24629}]);
              // http.flush();
    };

   it("It Should Load The External Templates",function(){

     var element = angular.element('<crime-table></crime-table>');
    compile(element)(rootScope);
    rootScope.$digest();
    // console.log(element);
   });



});
