angular.module('paginationModule',[])
.directive('pagination', function() {
  return {
    templateUrl:'CustomDirectives/Pagination.template.html'
  };
});
