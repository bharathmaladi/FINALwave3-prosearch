angular.module('ValidatedFormModule',[])
.directive('validForm', function() {
  return {
    templateUrl:'CustomDirectives/ValidatedForm.template.html'
  };
});
