var highland = require("highland");
var mongoUtil = require("../db/mongoUtil");
var getTags = require('./getTags');
var _ = require('underscore');
var nlp = require('nlp_compromise');
var session = require('../db/neo4jUtil.js');

var getEssentialTerms = function(searchText) {
  var terms = [];
  searchText = nlp.sentence(searchText).normal();
  return new Promise(function(resolve, reject) {
    var lexiconStream = highland();
    session.run('MATCH (terms) WHERE labels(terms) in ["organization","skills","location","roles","qualification"] return terms')
    .subscribe({
     onNext: function(lexicon) {
       lexicon._fields[0].labels.forEach(function(label) {
         var term = {};
         term[label] = lexicon._fields[0].properties.name;
         term[lexicon._fields[0].properties.name] = label;
         lexiconStream.write(term);
       })
     },
     onCompleted: function() {
        lexiconStream.end();
     },
     onError: function(err) {
       console.log("Error",err);
     }
   });


      lexiconStream.map(function(lexicon) {
        var lexicon = _.omit(lexicon, '_id', 'location', 'organization', 'skills', 'roles', 'qualification');
        var tag = getTags(searchText,lexicon);
        if (tag !== undefined) {
          return tag;
        };
      }).each(function(d) {
        if (d !== undefined) {
          terms.push(d);
        }
      }).done(function(){
        resolve(terms);
      });
  });
};

module.exports = getEssentialTerms;
