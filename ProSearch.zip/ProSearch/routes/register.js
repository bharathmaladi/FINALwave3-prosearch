var express = require('express');
var router = express.Router();
var request = require('request');
var mongoUtil = require('../db/mongoUtil');
var jwt = require('jsonwebtoken');
/* this api is for checking whether email allready exists or not */
router.get('/register/:email?', function(req, res) {
    var email = req.param('email');
    var db = mongoUtil.getDb();
    db.collection('users').find({
      'email': email
    }).toArray(function(err, user) {
      if (err) throw err;
      else {
        res.status(200).json(user[0]);
      }
    });
  })
  /*new user */
router.post('/register', function(req, res) {
  var object = req.body;
  var db = mongoUtil.getDb();
  db.collection('users').insertOne(object, function(err, doc) {
    if (err) {
      handleError(res, err.message, "Failed to create new contact.");
    } else {
      res.status(201).json(doc);
    }
  });
});

module.exports = router;
