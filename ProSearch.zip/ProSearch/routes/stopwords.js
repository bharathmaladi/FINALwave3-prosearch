var mongoUtil = require("../db/mongoUtil");
var getTags = require("./getTags.js");
var _ = require('underscore');


function removeStopWords(searchText,extractedTerm){
  try {
    var db = mongoUtil.getKeywordsDb();
    var regexp = /"(.*?)"/g;
    var results = searchText.match(regexp);
    var unknownwords = [];
    if(results) {
      results.forEach(function(matchedString) {
        unknownwords.push(matchedString.substring(1,matchedString.length-1));
        var indexOfMatchedString = searchText.indexOf(matchedString);
        var part1 = searchText.substring(-1,indexOfMatchedString)
        var part2 = searchText.substring(indexOfMatchedString+matchedString.length);
        searchText =part1+part2;
      });
    }
    unknownwords = unknownwords.filter(function(unknownword) {
      var toBeAdded = true;
      for(var term of extractedTerm) {
        if(term[unknownword]) {
          toBeAdded = false;
        }
      }
      if(toBeAdded) {
        return unknownword;
      }
    });
    var query = searchText.split(" ");

    return new Promise(function(resolve, reject) {

      var value = db.collection("stopwords").find({}).toArray(function(err, stopwords){
        if (err) {
          console.log("error in stopwords");
          reject(err);
        }
        else {
          stopwords.forEach(function(item,index){
            for(var i=0;i<query.length;i++){
              if(query[i] == item.stopwords){
                query.splice(i,1);
              }
            }
          });

          for (var j= 0; j <= extractedTerm.length;j++) {
            for (var i = 0; i < query.length; i++) {
              if (query[i] == _.keys(extractedTerm[j]) ) {
                query.splice(i,1);
              };
            }
          }
          unknownwords = unknownwords.concat(query);
        };
        resolve(unknownwords);
      });
    });
  } catch(err) {
    console.log("error in stopwords")
    console.log(err);
  }
};

module.exports = removeStopWords;
