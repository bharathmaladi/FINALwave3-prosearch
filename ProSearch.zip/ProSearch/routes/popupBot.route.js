var express = require("express");
var router = express.Router();
var session = require("../db/neo4jUtil.js");

  //<------api for auto complete------>
  router.get('/auto_nodes/:type,:hint', function(req, res) {
    var auto_data=[];
  			var type=req.params.type;
        var term=req.params.hint;
        console.log("AutoComplete");
        console.log(req.params);
        console.log(type);
        console.log(term);
        var query="MATCH (hint:"+type+") WHERE hint.name STARTS WITH \"" + term + "\" return hint.name";
        console.log("query is:");
        console.log(query);
      session.run(query)
      .subscribe(
     {
         onNext: function (record) {
             var hint = record.get('hint.name');
                auto_data.push(hint);
             console.log(hint);
         },
         onCompleted: function () {
             // Completed!
             console.log(auto_data);
             session.close();
             	res.send(auto_data);
         },
         onError: function (error) {
             console.log(error);
         }
     }
 );

  });//<------api for auto complete ends------>

module.exports = router;
