var express = require('express');
var router = express.Router();
var mongoUtil = require('../../db/mongoUtil');
var ObjectId = require('mongodb').ObjectID;
// returns list of all the keywords to the client
router.post('/queries', function(req,res) {
        var db = mongoUtil.getKeywordsDb();
         var unknownWords = req.body;
          var cursor = db.collection('keywords');
          var promises = [];
          unknownWords.forEach(function(unknownWord){
            var promise = cursor.find({"keyword":unknownWord.keyword,"label":unknownWord.label}).toArray(function(err, docs){
              console.log(docs.length);
              if(docs.length == 0){
                cursor.insert(unknownWord);
                console.log("New Keyword Inserted");
              }
              else if(docs.length>0){
                cursor.findOneAndUpdate(
                  { "keyword": unknownWord.keyword},
                  { $push: { "queries" : unknownWord.queries[0]}, $inc : { "count" : 1 } },
                  {returnNewDocument : true }, function(err, doc) {
                    if (!err) {
                      console.log("Existing Keyword Updated");
                    }
                  }
                );
              }
            });
            promises.push(promise);
          })

        Promise.all(promises,function() {
          res.send("success");
        });
});


module.exports = router;
