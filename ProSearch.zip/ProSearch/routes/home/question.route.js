var express = require('express');
var mongoUtil = require('../../db/mongoUtil');
var router = express.Router();
var ObjectId = require('mongodb').ObjectID;

// returns list of all the keywords to the client
router.get('/questions', function(req, res) {
  var db = mongoUtil.getKeywordsDb();
  var users = db.collection('questions').find().toArray(function(err, items) {
    if (err) throw err;
    else {
      res.send(items);
    }
  });
});




module.exports = router;
