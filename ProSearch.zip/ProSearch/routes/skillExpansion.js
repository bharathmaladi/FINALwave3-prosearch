var skillExpansion = function(session,skills) {
  var query = "MATCH (searchTerm:skills) WHERE searchTerm.name in "+skills+" OPTIONAL MATCH (searchTerm)-[:sameAs]-(sameAsSearchedTerm:skills) WITH collect(searchTerm) + collect(sameAsSearchedTerm) as searchTerms UNWIND searchTerms as term OPTIONAL MATCH (term)-[:hypernym]-(hyponym:skills) WITH term,collect(hyponym) as hyponyms OPTIONAL MATCH (hyponym)-[:sameAs]-(identicalHyponym:skills) WHERE hyponym in hyponyms WITH term,hyponym,hyponyms,identicalHyponym,REDUCE(collectionOfHyponyms=[],i in hyponyms|collectionOfHyponyms+i) as coh,REDUCE(collectionOfSearchTerm=[],t in [term]|collectionOfSearchTerm+t) as reducedSearchTerms,REDUCE(collectionOfHyponyms=[],h in [hyponym]|collectionOfHyponyms+h) as reducedHyponyms,REDUCE(sas=[],g in [identicalHyponym]|sas+g) as reducedIdenticalHyponyms WITH collect(reducedSearchTerms)+collect(reducedHyponyms)+collect(reducedIdenticalHyponyms)+collect(coh) as terms return REDUCE(termsToSearchProfilesOn=[],te in terms|termsToSearchProfilesOn+filter(k in te WHERE NOT k in termsToSearchProfilesOn)) as termsToSearchProfilesOn";
  return new Promise(function(resolve,reject){
    session.run(query).then(function(data) {
      var terms = "";
      data.records.forEach(function(record) {
        var relatedTerms = record._fields[0];
        relatedTerms.forEach(function(term) {
          terms+='"'+term.properties.name+'",';
        })
      });
      terms = "[" + terms.replace(/,\s*$/, "") + "]";
      resolve(terms);
    }).catch(function(err) {
      console.log(err);
    });
  });
};

module.exports = {
  expand: skillExpansion
};
