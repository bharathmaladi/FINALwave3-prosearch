angular.module('ProSearch')
.controller('search', ['searchResult','$filter', '$mdDialog', '$mdSidenav', 'team', '$scope', '$rootScope', 'autoComplete', '$http', '$routeParams', '$window', function(searchResult,$filter, $mdDialog, $mdSidenav, team, $scope, $rootScope, autoComplete, $http, $routeParams, $window) {


  // code for toggling the sidenav filters in medium and small screens



  $scope.onClickMenu = function() {
    $mdSidenav('left').toggle();
  };
  //
  $scope.hints=[];
  //authentication part. token should be present everywhere
  var token = $window.localStorage["authToken"];
  var base64Url = token.split('.')[1];
  var base64 = base64Url.replace('-', '+').replace('_', '/');
  $rootScope.loggedInUser = $window.atob(base64);
  $rootScope.email = JSON.parse($rootScope.loggedInUser).email;
  $rootScope.userName = JSON.parse($rootScope.loggedInUser).userName;
  $rootScope.userId = JSON.parse($rootScope.loggedInUser).user_id;
  $rootScope.searchTerm = $routeParams.searchTerm;

  // used for sortingArray on searchResult page ("sorted by part")
  var index=0;
  var sortingArray = [{
    "name": "Name",
    "type": "string"
  }, {
    "name": "Date",
    "type": "date"
  }, {
    "name": "Work Experience",
    "type": "number"
  }, {
    "name": "Rating",
    "type": "number"
  }];

  // to hide and to make visible the  buttons used in pagination
  var btn_next = document.getElementById("pagination");
  btn_next.style.visibility = "hidden";
  var btn_next11= document.getElementById("pagination1");
  btn_next11.style.visibility = "hidden";

  // variable used for storing the results when the search has happened
  $rootScope.searchResult = [];

  $http.get("/api/profiles/" + $rootScope.searchTerm).then(function(response) {

    $rootScope.searchResult = response.data.userProfiles.filter(function(userProfile) {
      if(userProfile) return userProfile;
    });
    console.log(response);
    console.log("unknown words");
    if(response.data.unknownwords)
    {
      $scope.unknownwords=response.data.unknownwords;
    }
    console.log($rootScope.unknownwords);
    $rootScope.selectedPersons = $rootScope.searchResult.length;
    console.log($rootScope.searchResult.length);
    $scope.popup(response.data.unknownwords);
    $scope.changePage(1);
  });


  //sorting based on selected value
  $scope.sortData = function(sortByValue) {
    var type = "";
    $rootScope.searchResult.profile.sort(function(a, b) {
      for (var i = 0; i < sortingArray.length; i++) {
        if (sortingArray[i].name == sortByValue) {
          type = sortingArray[i].type;
        }
      }
      //if type is numeric
      if (type == "number") {
        if (sortByValue == "Work Experience") {
          sortByValue = "workExperience";
        }
        if (sortByValue == "rating") {
          sortByValue = "metaInfo.relevance";
        }
        var nameA = a[sortByValue]; //.toUpperCase(); // ignore upper and lowercase
        var nameB = b[sortByValue]; //.toUpperCase(); // ignore upper and lowercase
        return nameA - nameB;
      }


      //if type is string
      if (type == "string") {
        var nameA = a.sections[0].chicklets[0].chickletData.name.value.toUpperCase(); // ignore upper and lowercase
        var nameB = b.sections[0].chicklets[0].chickletData.name.value.toUpperCase(); // ignore upper and lowercase

        if (nameA < nameB) {
          return -1;
        } else if (nameA > nameB) {
          return 1;
        }
        return 0;
      }

    });

  }
  $scope.data = {};
  $scope.flag = false;
  $scope.sortBy = [
    "Relevance",
    "Name",
    "Work Experience",
    "Rating"
  ];
  //Add to Wish List(to bind the dropdown)
  //Getting all the teams created by the user.
  $scope.teams = [];
  $scope.teamName = "";
  team.getTeams($rootScope.userId).success(function mySucces(teams) {
    $scope.teams = teams;

  });

  //adding a new team using fab icon
  $scope.getSelectdValue = function(teamId) {
    if (teamId == "addNew") {

      ($scope.addTeam = function(event) {
        $mdDialog.show({
          templateUrl: 'views/addTeamDialog.html',
          targetEvent: event,
          controller: data,
          scope: $scope
        })
      })();

      //for hiding and using cancel
      function data($scope, $mdDialog) {
        $scope.hide = function() {
          $mdDialog.hide();
        };
        $scope.cancel = function() {
          $mdDialog.cancel();
        };

        //for creating a new team or else pushing the selected profiles in
        //an existing team
        $scope.saveData = function() {
          var newTeamDetails = {};
          newTeamDetails["name"] = $scope.Name;
          newTeamDetails["description"] = $scope.Description;
          newTeamDetails["teamMembers"] = [];
          $scope.teams.push(newTeamDetails);
          team.addTeam(newTeamDetails, $rootScope.userId);
          alert('New team added successfully');
          $mdDialog.hide();
        };
      }

    } else {
      for (var i = 0; i < $scope.teams.length; i++) {
        if ($scope.teams[i]._id == teamId) {
          $scope.teams[i].teamMembers.push($scope.selectedProfiles);
        }
      }
      for (var i = 0; i < $scope.teams.length; i++) {
        $scope.teams[i]._id = "ObjectId(" + $scope.teams[i]._id + ")";
      }

      $http.patch("/api/team/" + $rootScope.userId, $scope.teams).then(function(response) {
      });
    }
  }


  //for saving the search
  $scope.saveSearch = function(searchTerm) {
    alert("Search Saved Successfully");
    $scope.searches = {};
    $scope.searches["savedSearch"] = searchTerm;
    var curDate=new Date();
    curDate  = $filter('date')(curDate, "dd-MM-yyyy");
    curDate=curDate.toString();
    $scope.searches["savedOn"]=curDate;
    searchResult.addSaveSearch($scope.searches, $rootScope.userId);
  };
  (function() {

    'use strict';
    $scope.topDirections = ['left', 'up'];
    $scope.isOpen = false;

    $scope.availableModes = ['md-scale'];
    $scope.selectedMode = 'md-scale';

    $scope.availableDirections = ['up'];
    $scope.selectedDirection = 'up';
  })();

  $scope.logout = function(event) {
    $window.localStorage.removeItem("authToken");
    $window.location.href = "/login.html";
  };


  // Pagination code

  $scope.current_page = 1;
  $scope.records_per_page = 10;


  $scope.prevPage = function() {

    if ($scope.current_page > 1) {
      $scope.current_page--;
      $scope.changePage($scope.current_page);
    }
  }

  $scope.nextPage = function() {
    if ($scope.current_page < $scope.numPages()) {
      $scope.current_page++;
      $scope.changePage($scope.current_page);
    }
  }

  $scope.changePage = function(page) {
    $scope.data = [];
    var btn_next = document.getElementById("btn_next");
    var btn_prev = document.getElementById("btn_prev");
    var listing_table = document.getElementById("listingTable");
    var page_span = document.getElementById("page");
    page_span.style.visibility = "visible";

    var btn_next1 = document.getElementById("btn_next1");
    var btn_prev1 = document.getElementById("btn_prev1");
    var listing_table1 = document.getElementById("listingTable1");
    var page_span1 = document.getElementById("page1");
    page_span1.style.visibility = "visible";

    // Validate page
    if (page < 1) page = 1;
    if (page > $scope.numPages()) page = $scope.numPages();

    if($rootScope.searchResult.length > 0) {
      for (var i = (page - 1) * $scope.records_per_page; i < (page * $scope.records_per_page) && i < $rootScope.searchResult.length; i++) {
        $scope.data.push($rootScope.searchResult[i]);
      }
    }

    page_span.innerHTML = page + "/" + $scope.numPages();
    page_span1.innerHTML = page + "/" + $scope.numPages();

    if (page == 1) {
      btn_prev.style.visibility = "hidden";
      btn_prev1.style.visibility = "hidden";
    } else {
      btn_prev.style.visibility = "visible";
      btn_prev1.style.visibility = "visible";
    }

    if (page == $scope.numPages()) {
      btn_next.style.visibility = "hidden";
      btn_next1.style.visibility = "hidden";
    } else {
      btn_next.style.visibility = "visible";
      btn_next1.style.visibility = "visible";
    }
  }

  $scope.numPages = function() {
    return Math.ceil($rootScope.searchResult.length / $scope.records_per_page);
  }


  // card toggle ie view more in cards

  $scope.selectedProfiles = [];

  $scope.onProfileToggle = function(flag, profile) {
    if (flag)
    $scope.selectedProfiles.push(profile);
    else {
      $scope.selectedProfiles.forEach(function(selectedProfile, i) {
        if (selectedProfile === profile) {
          $scope.selectedProfiles.splice(i, 1);
        };
      });
    }
    console.log($scope.selectedProfiles);
  };

  // ========================= popups ==========================================================

  $scope.popup=function(searchTerm){
    console.log("popup called");
    if($scope.unknownwords) {
      if($scope.unknownwords.length>0) {
        console.log("inside popup unknowwords found");
        document.getElementById('light').style.display='initial';
      }
    }
  }

  $scope.close=function() {
    document.getElementById('light').style.display='none';
  }

  $http.get('/api/questions').success(function(data){
    $scope.todo=data[0];
  });

  $scope.type_selected=true;
  $scope.type_last=false;
  var que;
  var answers = [];

  $scope.keyword=function(type){
    $scope.todos_question=[];
    $scope.todos_question.push($scope.todo[type]);
    $scope.type_selected=false;

  }

  //=============================== end of popups ===========================================


  //================add queries===============
  $scope.hints=[];
  $scope.selectedkeyword=null;
  $scope.searchKeywordText=null;
  $scope.keywords="";
  $scope.searchKeywordText='';

  $scope.similarKeywords = function(query){
    return autoComplete.getHints($scope.keyword_type,query).then(function(data){
      return data.data;
    });
  }


  $scope.addQuery=function(query,type,hints,unknowwords){
    console.log(hints);
    var arry=[];
    for (var i = 0; i < unknowwords.length; i++) {
      var que = {"keyword":unknowwords[i].toLowerCase(),"count":1,"disabled":false,"label":type,"queries":[{"query":query,"userinput":hints}]};
      arry.push(que);
    }
    $http.post('/api/queries',arry);
  }
  //================end of add queries============
}]);
