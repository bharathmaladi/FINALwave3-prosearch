angular.module('ProSearch')
  .service('register', function($http, $window, $location) {
    this.newUser = function(username, email, password) {
      var registerCredentials = {
        "username": username,
        "email": email,
        "password": password,
        "teams": [],
        "savedSearch": [],
        "archiveTeams": []
      };
      var user = $http.get('api/register/' + registerCredentials.email).success(function(user) {
        if (user.email == registerCredentials.email) {
          alert("email existed already");
        } else {
          return $http.post('api/register', registerCredentials);
        }
      });
    };
  });
