angular.module('ProSearch')
  .service('autoComplete', ['$http', '$q', function($http, $q) {
    this.getSkill = function(skill) {
      return $http.get('/api/autoCompleteSkill/' + skill);
    }
    this.getLocation = function(location) {
      return $http.get("/api/autoCompleteLocation/" + location);
    }
    this.getDesignation = function(role) {
      return $http.get("/api/autoCompleteDesignation/" + role);
    }
    this.getHints = function(type,hints) {
      return $http.get("/api/auto_nodes/"+type+","+hints);
    }

  }]);
