angular.module('ProSearch')
  .service('authenticate', function($http, $window, $location) {
    this.login = function(email, password) {
      var loginCredentials = {
          "email": email,
          "password": password
        }
        /*calls the authenticate api */
      return $http.post('/api/authenticate', loginCredentials);
    };
  });
