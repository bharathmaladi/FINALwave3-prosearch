angular.module('ProSearch')
  .service('filter', ["$http", function($http) {
    this.readFilters = function() {
      return $http.get('/api/filters');
    };

    this.getDesignation = function() {
      return $http.get('/api/designation');
    };
  }]);
