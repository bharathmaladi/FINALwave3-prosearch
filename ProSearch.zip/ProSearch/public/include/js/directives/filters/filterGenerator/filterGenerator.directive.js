angular.module('ProSearch')
  .directive('filterGenerator', function() {
    return {
      templateUrl: 'include/js/directives/filters/filterGenerator/filterGenerator.tmpl.html',
      scope: {
        type: '<',
        values: '<'
      }
    }
  });
