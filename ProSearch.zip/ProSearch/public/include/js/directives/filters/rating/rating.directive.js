angular.module('ProSearch')
  .directive('rate', function() {
    return {
      templateUrl: 'include/js/directives/filters/rating/rating.tmpl.html',
      scope: {
        type: '<',
        values: '<'
      }
    }
  })
