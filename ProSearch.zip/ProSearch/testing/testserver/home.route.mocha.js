var supertest = require("supertest");
var should = require("should");

var server = supertest.agent("http://localhost:8080");

describe("Testing homepage",function(){
  it("should return savedsearches",function(done){
    server
    .get("/api/savedSearch")
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      // console.log(res.text);
      res.res.statusCode.should.equal(200);
      done();
    });
  });

  it("should delete savedsearch",function(done){
    var id=41;
    server
    .delete("/api/savedSearch/"+id)
    .expect("Content-type",/json/)
    .expect(204)
    .end(function(err,res){
      res.res.statusCode.should.equal(204);
      done();
    });
  });

  it("should return smartsearches",function(done){
    server
    .get("/api/smartSearch")
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      res.res.statusCode.should.equal(200);
      done();
    });
  });
});
