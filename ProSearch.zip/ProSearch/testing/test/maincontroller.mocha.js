describe('mainCtrl',function() {
  beforeEach(module('ProSearch'));

  var $controller,$http,$httpBackend;
  beforeEach(inject(function(_$controller_,_$timeout_){
		$controller = _$controller_;
    $timeout = _$timeout_;

	}));

  describe('$scope searchResults',function(){
    it('gets the search results and display a new view with the search results',function(){
      var $scope = {};
      var controller = $controller('mainCtrl', { $scope:$scope });
      $scope.searchTerm="Java";
      $scope.searchResults($scope.searchTerm);

      setTimeout(function() {
        expect($scope.searchResult.length).not.toEqual(null);
      }, 1000);
    });
  });
});
  // describe('$scope removeSavedSearch',function(){
  //   it('removes a saved search from the list of already stored savedsearches',function(){
  //     var $scope;
  //     var controller = $controller('mainCtrl',{$scope :$scope});
  //     var id;
  //     $scope.removeSavedSearches();
  //     setTimeout(function() {
  //       expect($scope.removeSavedSearch.id).to.be.equal(0);
  //     }, 1000);
  //   });
  // });
  //
  // describe('$scope logout',function(){
  //   it('perform the logout operation',function(){
  //     var $scope={};
  //     var controller=$controller('mainCtrl',{$scope:$scope});
  //     $scope.logout();
  //     setTimeout(function() {
  //       expect($window.$scope.localStorage.removeItem.event).toBe(true);
  //     }, 1000);
  //
  //   }
  // })
  //
  // describe('$scope signUp',function(){
  //   it('open the signup page for sign up operation',function(){
  //     var $scope={};
  //     var controller=$controller('mainCtrl',{$scope:$scope});
  //     $scope.signUp();
  //     setTimeout(function() {
  //       expect($scope.event).toBe(true);
  //     }, 1000);
  //
  //   })
  // })
