angular.module('ProSearch')
  .controller('designationCtrl', ['$scope', 'filter', '$http', '$routeParams', function($scope, filter, $http, $routeParams) {
   $scope.values=[];
  (function() {
      return filter.getDesignation().then(function(response) {
        for(var i=0;i<response.data.length;i++){
          $scope.values.push(response.data[i].designation);
        }
        console.log(response.data.designation);

        if (typeof response.data === 'object') {
          return response.data;
        } else {
          // invalid response
          return $q.reject(response.data);
        }
      });
    })();
  }]);
