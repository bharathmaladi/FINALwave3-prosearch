angular.module('ProSearch')
  .controller('skillsCtrl', ['$scope', 'autoComplete', '$http', '$routeParams', function($scope, autoComplete, $http, $routeParams) {
    $scope.searchSkill = "";
    $scope.selectedSkill = [];
    $scope.isDisabled = false;
    $scope.noCache = false;

    $scope.searchSkill = function(str1) {
      return autoComplete.getSkill(str1).then(function(response) {
        if (typeof response.data === 'object') {
          return response.data;
        } else {
          // invalid response
          return $q.reject(response.data);
        }
      });
    }
  }]);
