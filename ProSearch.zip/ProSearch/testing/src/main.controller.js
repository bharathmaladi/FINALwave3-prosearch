angular.module('ProSearch')
  .controller('mainCtrl', ['$scope', '$q', '$http','$mdDialog','$window', '$rootScope', function($scope, $q, $http,$mdDialog,$window,$rootScope) {

    $scope.searchTerm = "";
    //Searching
    $scope.searchResult = [];
    $scope.searchResults = function(searchTerm) {
      //alert(searchTerm);
      alert(searchTerm);
      //Getting the user profiles from the json
      $http.get("http://localhost:3000/Profile").then(function(response) {
        for (var i = 0; i < response.data.length; i++) {
          if ((response.data[i].Name.indexOf(searchTerm) != -1) || (response.data[i].address.indexOf(searchTerm) != -1) || (response.data[i].ToolsAndTechnology.indexOf(searchTerm) != -1) || (response.data[i].Organization.indexOf(searchTerm) != -1)) {
            $scope.searchResult.push(response.data[i]);
          }
        }
      });
    }
    //Smart search part
    $scope.smartSearch = [];
    //Calling the smart search API
    $http.get('/api/smartSearch').then(function(response) {
      for (var i = 0; i < response.data.length; i++) {
        $scope.smartSearch.push(response.data[i]);
      }
    });

    //Saved search part
    $scope.savedSearch = [];
    //Calling the saved search API
    $http.get('/api/savedSearch').then(function(response) {
      for (var i = 0; i < response.data.length; i++) {
        $scope.savedSearch.push(response.data[i]);
      }
    });

    $scope.removeSavedSearch = function(event,id) {
      //  alert(id);
          var confirm = $mdDialog.confirm()
            .title('Would you like to remove Search?')
            .targetEvent(event)
            .ok('Confirm')
            .cancel('Nope');
          $mdDialog.show(confirm).then(function()
          {

              //Calling the API to delete the saved search
              $http.delete('/api/savedSearch/'+id).then(function(response)
              {
                alert('Team has been Removed.');
              });

            },
            function()
            {
              alert('Team has not been Removed.');
            });
        };

        $scope.logout = function(event) {
          $window.localStorage.removeItem("authToken");
          $window.location.href="/login.html";
        };

        function data($scope, $mdDialog) {
          $scope.hide = function() {
            $mdDialog.hide();
          };
          $scope.cancel = function() {
            $mdDialog.cancel();
          };

        }
        $scope.signUp = function(event) {
          //Dialog box
          $mdDialog.show({
            templateUrl: 'views/signUp.html',
            targetEvent: event,
            controller: data,
            scope: $scope
          })
        };


        //$scope.setLoggedInUser = function() {
          var token = $window.localStorage["authToken"];
          var base64Url = token.split('.')[1];
          var base64 = base64Url.replace('-', '+').replace('_', '/');
          $rootScope.loggedInUser = $window.atob(base64);
          //console.log($rootScope.loggedInUser);
        //}

        // function data($scope, $mdDialog) {
        //
        //   $scope.saveData = function() {
        //     var newTeamDetails = {};
        //     newTeamDetails["name"] = $scope.Name;
        //     newTeamDetails["description"] = $scope.Description;
        //     $scope.teams.push(newTeamDetails);
        //     console.log($scope.teams);
        //     team.signUp(newTeamDetails);
        //         // alert('New team added successfully');
        //
        //       //console.log($scope.teams);
        //     $mdDialog.hide();
        //   };
        // }

  }]);
