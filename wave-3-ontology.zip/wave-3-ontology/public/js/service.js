mindMap.factory('GetNameService', function ($http,$q)
{
    return {
        getName: function(str) {
        var url="/auto_nodes/"+str;
            return $http.get(url)
                .then(function(response) {
                    if (typeof response.data === 'object')
                        return response.data;
                    else
                        return $q.reject(response.data);
                }, function(response) {
                        return $q.reject(response.data);
                });
        }
    };
});

mindMap.service('GetNodeService', function ($http,$q)
{
        this.getNodes = function() {
            return $http.get('/nodes')
        }
        this.getTerms = function(str) {
            return $http.get('/auto_nodes/'+str)
        }
        this.getLinks = function() {
            return $http.get('/links')
        }
        this.getNodesGroup = function(text,hop) {
              return $http.get('/searched_nodes/'+text+'/'+hop)
        }
        this.getLinksId = function(text,hop) {
              return $http.get('/searched_links/'+text+'/'+hop)
        }
        this.getRelationProp = function(src,rel) {
              return $http.get('/rel_prop/'+src+'/'+rel)
        }
        this.getRelationName = function(src,rel,label) {

            return $http.get('/relationName/'+src+'/'+rel+'/'+label)
        }
        this.orig_nodes = function(src,rel) {

            return $http.get('/orig_nodes')
        }
        this.orig_links = function(src,rel) {

            return $http.get('/orig_links')
        }
});
mindMap.service('PostNodeService', function ($http,$q)
{
        this.postNodes = function(objstr) {
              return $http.get('/addnodes/'+objstr)
        }
        this.postNewNodes = function(objstr) {
              return $http.get('/addnewnodes/'+objstr)
        }
        this.getRelation = function() {
              return $http.get('/relation')
        }
        this.getLabel = function() {
              return $http.get('/label')
        }
        this.addProperty = function(src,rel,tar,obj) {
              return $http.get('/addProperty/'+src+'/'+rel+'/'+tar+'/'+obj);
        }
});
mindMap.service('DeleteNodeService', function ($http,$q)
{
        this.deleteNodes = function(id) {
            return $http.get('/deleteNodes/'+id)
        }
        this.deleteKeys = function(key,src) {
            return $http.get('/deleteKeys/'+key+'/'+src)
        }
});

mindMap.service('EditNodeService', function ($http,$q)
{
        this.editNodes = function(key,value,src) {
            return $http.get('/editNodes/'+key+'/'+value+ '/'+src)
        }
});
