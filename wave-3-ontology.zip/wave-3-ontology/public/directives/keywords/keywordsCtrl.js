mindMap.controller('keywordsCtrl', function($scope,$http,$mdDialog) {
  $scope.cancel = function() {
        $mdDialog.cancel();
      };


   $http.get('http://localhost:8080/properties').success(function(data){
     $scope.properties = data[0];
    $scope.node_props=$scope.properties.node_props;
    $scope.relations=$scope.properties.relations;
    $scope.relation_props=['none'];
  // console.log($scope.properties);
  });

    $scope.getProps = function(relation){
     for(var i=0;i<$scope.relations.length;i++){
         if(relation == $scope.relations[i]){
           $scope.relation_props = $scope.properties[relation];
         }
     }
}
// FETCH THE KEYWORD FROM DB AND COUNT THE KEYWORDS OCCURENCE
  $http.get('http://localhost:8080/keywords').success(function(data){
    $scope.data=data;
    $scope.count=0;
    $scope.todos=[];
    for(var k=0;k<$scope.data.length;k++){
      for(var l=0;l<$scope.todos.length;l++){
        if($scope.data[k].keyword==$scope.todos[l].keyword){
         var found=true;
        break;
        }
        else{
         found=false;
        }
      }
      if(!found){
        var obj={};
        obj.keyword=$scope.data[k].keyword;
        obj.count=1;
        $scope.todos.push(obj);
      }
      else{
           for(var z=0;z<$scope.todos.length;z++){
             if($scope.todos[z].keyword==$scope.data[k].keyword){
               $scope.todos[z].count++;
             }
           }
      }
    }

     $scope.selected = [];
     $scope.toggle = function (item, list) {
       var idx = list.indexOf(item);
      //  var ind=$scope.todos.indexOf(item);
       if (idx > -1) {
         list.splice(idx, 1);
        //  $scope.todos.value[ind]!=$scope.item.value[ind];
       }
       else {
         list.push(item);
          // $scope.todos.value[ind]!=$scope.item.value[ind];
       }
     };

     $scope.exists = function (item, list) {
       return list.indexOf(item) > -1;
     };

     $scope.isIndeterminate = function() {
       return ($scope.selected.length !== 0 &&
           $scope.selected.length !== $scope.todos.length);
     };

     $scope.isChecked = function() {
       return $scope.selected.length === $scope.todos.length;
     };

     $scope.toggleAll = function() {
       if ($scope.selected.length === $scope.todos.length) {
         $scope.selected = [];
       } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
         $scope.selected = $scope.todos.slice(0);
       }
     };
});
//INJECT THE DISPLAYING QUERY FILE

$scope.showTabDialog=function(eve,keywords){

   templateUrl:'includes/views/query.html'
};
 $scope.query=function(eve,keyword){
  key=keyword;

  $mdDialog.show({
    controller:  'DialogController',
    templateUrl: 'includes/views/query.html',
    parent: angular.element(document.body),
    targetEvent: eve,
    // clickOutsideToClose: true
})};


// INJECT THE DELETE FILE
$scope.deletefun = function(ev,word,$mdDialogs) {
  // console.log(word);
que=word;
$mdDialog.show({
controller:  'DialogController',
templateUrl: 'includes/views/delete.html',
parent: angular.element(document.body),
targetEvent: ev,

clickOutsideToClose: true

})};

})

// .controller('DialogController',function($scope,$mdDialog,$rootScope,$http){
//
//   $scope.cancel = function() {
//         $mdDialog.cancel();
//       };
//
//   // $scope.val = 'ece';
//
// // var data = {
// //   keyword:que
// // }
// $scope.deleteQuery = function(val) {
//   // alert($scope.val);
//   $scope.val=que;
//   alert($scope.val);
//   $http.post("http://localhost:8080/keywords", JSON.stringify(data));
//   console.log("called deleteQuery");
// }
// // DISPLAY THE QUERY
//   $http.get("http://localhost:8080/keywords").success(function(data) {
//     $scope.data = data;
//   })
//
// var queObj=[];
//   $http.get('http://localhost:8080/keywords').success(function(data) {
//        $scope.que_data=data;
//       for(var i=0;i<$scope.que_data.length;i++){
//           if($scope.que_data[i].keyword==key){
//              $scope.obj={};
//              $scope.obj.query=$scope.que_data[i].query;
//              queObj.push($scope.obj);
//         }
//     }
//   });
//   $scope.list=queObj;
// // };
// })
