angular.module('mindMap')
 .directive('graphProperties',function(){
   return{
     templateUrl: 'directives/graphProperties/graphProperties.template.html',
     controller: 'EntitiesCtrl'
   }
 })
