// =================================================================
// get the packages we need ========================================
// =================================================================
var express 	= require('express');
var app         = express();
var bodyParser  = require('body-parser');
var underscore=require('underscore');
var mongoose    = require('mongoose');
// var mongoUtil = require('./db/mongoUtil');
var mongoClient = require('mongodb').MongoClient;
var url = 'mongodb://10.219.85.69/smartSearchDb';var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.69:7687", neo4j.auth.basic("neo4j", "1234"));
var path = require('path');
var session = driver.session();
port=8080;


// use body parser so we can get info from POST and/or URL parameters
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));


// =================================================================
// routes ==========================================================
// =================================================================


// basic route (http://localhost:8080)
var errs;
mongoClient.connect(url, function(err, database) {
	errs=err;

if(errs) {
   console.log('Unable to connect to the mongoDB server--Failed to find  Requested Url');
 }
 else {
     db = database;
     console.log('Server Started');
 }
});


					// <-----api for home page------->
app.get('/', function(req, res) {
	res.sendFile(path.join(__dirname + '/index.html'));
});	// <-----api for home page ends------->



//	<-----api for getting labels from mongoDB------->
app.get('/relation', function(req, res) {
		var cursor  =db.collection('ontologyRelations');
		var sections=cursor.find().toArray(function(err, docs) {
		res.json(docs);
		});
});	// <-----api for getting relations from mongoDB ends------->


			//<-----api for getting labels from mongoDB------->
app.get('/label', function(req, res) {
		var label  =db.collection('ontologyLabels');
		var label_array=label.find().toArray(function(err, docs) {
		res.json(docs);
		});
});	// <-----api for getting labels from mongoDB ends------->



																							///neo4j

					//<-----api for getting all node names------->
app.get('/nodes', function(req, res) {
	var node_data=[];
	session.run( "MATCH (n) RETURN n")
	  .then( function( result ) {
			for(var i=0;i<result.records.length;i++)
			{
			node_data.push(result.records[i]._fields[0].properties.name);
			}
			res.send(node_data);
		  })
});		//<-----api for getting all node names ends------->

var link=[];

var check=function(i,result)
{
	var full_link_data={};
	full_link_data["source" ]=result.records[i]._fields[0].start.properties.id;
	full_link_data["target"]=result.records[i]._fields[0].end.properties.id;
	full_link_data["value"]=1;
	full_link_data["relation"]=result.records[i]._fields[0].segments[0].relationship.type;
	link.push(full_link_data);
};

					//<-----api for getting all links------->
app.get('/links', function(req, res) {
	console.log("links");
	session.run("MATCH p=(:skills)-[r]->(:skills) RETURN p")
	  .then( function(result) {

			for(var i=0;i<result.records.length;i++)
			{
				check(i,result);
			}
			res.send(link);
		  })
});	//<-----api for getting all links ends------->




var all_node=[];
var link_data=[];
var searchText=function(i,result)
{
	var node={};
	var nodes1={};
	var link={};
	link['source']=result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].start.properties.name;
	link['target']=result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].end.properties.name;
	link['relation']=result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].relationship.type;
	//console.log(result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].relationship);
	all_node.push(link['source']);
	all_node.push(link['target']);
	link_data.push(link);

};

		//<-----api for getting links for searched node------->
app.get('/searched_links/:node_name/:hopcount', function(req, res) {

		var val=req.params.node_name;
		var h=req.params.hopcount;

	session.run( "MATCH p=(n)-[r*.."+h+"]-(result) WHERE n.name='" + val +  "' RETURN p")
		  .then( function(result) {
				link_data=[];
				for(var i=0;i<result.records.length;i++)
				{
				searchText(i,result);
				}

				res.send(link_data);
	  })
});	//<-----api for getting links for searched node ends------->


var uniqnode=[];
var uniqnodefn=function(i,uniq_node)
{
	uniqnode.push({"id":uniq_node[i],"group":1});
};

		//<-----api for getting related nodes of searched node------->
app.get('/searched_nodes/:node_name/:hopcount', function(req, res) {
link_data=[];var uniq_node=[];
    var value=req.params.node_name;
    var h = req.params.hopcount;
    session.run( "MATCH p=(n)-[r*.."+h+"]-(result) WHERE n.name='" + value +  "' RETURN p")
        .then( function(result) {
                    if(result.records=="")
                    {
                        session.run( "MATCH (n{name:'"+value+"'}) RETURN n")
                          .then( function( result ) {
                                    //console.log(result.records[0]._fields[0].properties);
                                    var single_node=[];
                                    single_node.push({"id":result.records[0]._fields[0].properties.name,"group":1});
                                    res.send(single_node);
                            })
                    }
else{
            link_data=[];uniqnode=[];all_node=[];
        for(var i=0;i<result.records.length;i++)
            {
                searchText(i,result);
            }
            uniq_node=underscore.uniq(all_node);
            for(var i=0;i<uniq_node.length;i++)
            {
                uniqnodefn(i,uniq_node);
            }
        //    console.log(uniqnode);
            res.send(uniqnode);
        }
})
});//<-----api for getting related nodes of searched node ends------->



	//<-----api for getting all links for original graph------->
app.get('/orig_links/', function(req, res) {
	session.run( "MATCH p=(n)-[r]->(result) RETURN p")
		  .then( function(result) {
				link_data=[];
				for(var i=0;i<result.records.length;i++)
				{
				searchText(i,result);
				}
				res.send(link_data);
	  })
});//<-----api for getting all links for original graph ends------->


			//<-----api for getting all nodes for original graph------->
app.get('/orig_nodes', function(req, res) {
link_data=[];var uniq_node=[];
    session.run( "MATCH p=(n)-[r]-(result) RETURN p")
        .then( function(result) {

                    if(result.records=="")
                    {
                        session.run( "MATCH (n) RETURN n")
                          .then( function( result ) {

                                    var single_node=[];
                                    single_node.push({"id":result.records[0]._fields[0].properties.name,"group":1});
                                    res.send(single_node);
                            })
                    }
else{
            link_data=[];uniqnode=[];all_node=[];
        for(var i=0;i<result.records.length;i++)
            {
                searchText(i,result);
            }
            uniq_node=underscore.uniq(all_node);
            for(var i=0;i<uniq_node.length;i++)
            {
                uniqnodefn(i,uniq_node);
            }
             res.send(uniqnode);
        }
})
});

//<-----api for getting all nodes for original graph ends------->
var auto_data=[];
var check2=function(i,result)
{
	auto_data.push(result.records[i]._fields[0].properties);

};
//<------api for auto complete------>
app.get('/auto_nodes/:str', function(req, res) {

			var s=req.params.str;
		session.run( "MATCH (n) WHERE n.name STARTS WITH '" + s +  "' RETURN n")
	  .then( function( result ) {
			auto_data=[];
				for(var i=0;i<result.records.length;i++)
				{
				check2(i,result);
				}
				res.send(auto_data);

	  })

});//<------api for auto complete ends------>


//<-----api for getting relation between specified source and target nodes------->
app.get('/relationName/:src/:tar/:label', function(req, res) {

		var source=req.params.src;
		var target=req.params.tar;
		var label=req.params.label;
	console.log("MATCH (n:"+label+"{name:'"+source+"'})-[r]-(n1:"+label+"{name:'"+target+"'})RETURN r");
		session.run("MATCH (n:"+label+"{name:'"+source+"'})-[r]-(n1:"+label+"{name:'"+target+"'})RETURN r")

	  .then( function( result ) {
			if(result.records.length==0)
				res.send("null");
			else
				res.send(result.records[0]._fields[0].type);
	  })
});//<-----api for getting relation between specified source and target nodes ends------->


function convertToText(obj) {
        var string = [];
    if (typeof(obj) == "object" && (obj.join == undefined)) {
        string.push("{");
        for (prop in obj) {
            string.push(prop, ": ", convertToText(obj[prop]), ",");
        };
				string.pop();
        string.push("}");

    //is array
    } else if (typeof(obj) == "object" && !(obj.join == undefined)) {
        string.push("[")
        for(prop in obj) {
            string.push(convertToText(obj[prop]), ",");
        }
        string.pop();
				string.push("]")

    //is function
    } else if (typeof(obj) == "function") {
        string.push(obj.toString())

    //all other values can be done with JSON.stringify
    } else {
        string.push(JSON.stringify(obj))
    }

    return string.join("")
}


//<-----api for adding new nodes and relation with existing nodes------->
app.get('/addnodes/:objstr', function(req, res) {
			var s=JSON.parse(req.params.objstr);
			var t = "";

			if(Object.keys(s.properties).length){

					t=convertToText(s.properties);
				}
				else {

					t = " ";
				}
				var key=Object.keys(s.properties)
				var split_keys =key;
				var split_values = [];
				console.log("MATCH (n1:"+s.label+"{name:'"+s.source+"'}) MERGE  (n1)-[r:"+s.relation+" "+t+"]->(n2:"+s.label+"{name:'"+s.target+"'}) RETURN r,n2");
if(s.flag==1)
 {
 session.run("MATCH (n1:"+s.label+"{name:'"+s.source+"'}),(n2:"+s.label+"{name:'"+s.target+"'}) MERGE (n1)-[r:"+s.relation+t+"]-(n2) RETURN r")
 	  .then( function(result) {
 			console.log("relation added");
 	  })
 }
 else if(s.flag==0){
	 console.log("inside else of s.flag");
 		session.run("MATCH (n1:"+s.label+"{name:'"+s.source+"'}) MERGE  (n1)-[r:"+s.relation+t+"]-(n2:"+s.label+"{name:'"+s.target+"'}) RETURN r,n2")
 		.then( function( result ) {
 			console.log("newnode added");
 		})
 }
 else{
	 for (var i = 0; i <Object.keys(s.properties).length; i++) {
		 split_values[i]=s.properties[split_keys[i]];

 		session.run("MATCH (n:"+s.label+"{name:'"+s.source+"'})-[r:"+s.relation+"]-(n1:"+s.label+"{name:'"+s.target+"'}) SET r."+split_keys[i]+"='"+split_values[i]+"' RETURN r")
 			.then( function(result) {
 				console.log('property alone added !!');
 				res.send(result);
 				})
 	}

 }
});//<-----api for adding new nodes and relation with existing nodes ends------->


			//<-----api for adding new nodes------->
app.get('/addnewnodes/:objstr', function(req, res) {
			console.log(req.params.objstr);

			var s=JSON.parse(req.params.objstr);
			console.log(s);
			if(Object.keys(s.properties).length){

					t=convertToText(s.properties);
				}
				else {
					console.log("no properties");
					t = " ";
				}
		session.run("CREATE (n1:"+s.label+"{name:'"+s.source+"'}),(n1)-[r:"+s.relation+t+"]->(n2:"+s.label+"{name:'"+s.target+"'}) RETURN r,n2")
		.then( function( result ) {
			console.log("newnewnode added");
			res.send("added");
		})

});	//<-----api for adding new nodes ends------->

			//<-----api for deleting a node------->
app.get('/deleteNodes/:objstr', function(req, res) {

			var s=req.params.objstr;
			console.log(s);
			session.run("MATCH (n { name:'"+s+"' }) DETACH DELETE n")
				.then( function( result ) {
						console.log("Node deleted");
					})
});//<-----api for deleting a node ends------->

			//<-----api for getting properties of a relation------->
app.get('/rel_prop/:src/:rel', function(req, res) {
		var src=req.params.src;
		var rel=req.params.rel;

			session.run("MATCH (n{name:'"+src+"'})-[r:"+rel+"]-(n1) RETURN r")
				.then( function(result) {
					res.send(result.records[0]._fields[0].properties);
					})
});	//<-----api for getting properties of a relation ends------->

			//<-----api for editing properties of a relation------->
app.get('/editNodes/:key/:value/:src', function(req, res) {
		var key=req.params.key;
		var value=req.params.value;
		var src=req.params.src;
		var split_keys = [];
		var split_values = [];

		split_keys = key.split(',');
		split_values = value.split(',');
		for (var i = 0; i < split_keys.length; i++) {
			session.run("MATCH (n{name:'"+src+"'})-[r]-(n1) SET r. "+split_keys[i]+"='"+split_values[i]+"' RETURN r")
				.then( function(result) {
					console.log('Node Edited !!');
					res.send(result);
					})
		}

});//<-----api for editing properties of a relation ends------->

//<-----api for deleting properties of a relation------->
app.get('/deleteKeys/:key/:src', function(req, res) {
			var src=req.params.src;
			var key=req.params.key;
			session.run("MATCH (n{name:'"+src+"'})-[r]-(n1) REMOVE r."+key+" RETURN r")
				.then( function( result ) {
						console.log("Property deleted");
					})
});//<-----api for deleting properties of a relation------->

		//<-----api for adding properties to a relation------->
app.get('/addProperty/:src/:rel/:tar/:obj', function(req, res) {
			var src=req.params.src;
			var rel=req.params.rel;
			var tar=req.params.tar;
			var obj=JSON.parse(req.params.obj);

			var split_keys = Object.keys(obj);
			var split_values = [];
			for (var i = 0; i < split_keys.length; i++) {
				split_values[i] = obj[split_keys[i]];
			}

	for (var i = 0; i < split_keys.length; i++) {
		session.run("MATCH (n{name:'"+src+"'})-[r:"+rel+"]-(n1{name:'"+tar+"'}) SET r. "+split_keys[i]+"='"+split_values[i]+"' RETURN r")
			.then( function( result ) {
					console.log("Properties added !!");
				})
	}

});	//<-----api for adding properties to a relation ends------->


// ERROR HANDLING
app.get('*', function(req, res, next) {
  var err = new Error("Invalid URL");
  err.status = 404;
  next(err);
});

// handling 404 errors
app.use(function(err, req, res, next) {
  if(err.status !== 404) {
    return next();
  }
  res.send(err.message);
	 next();
});





// =================================================================
// start the server ================================================
// =================================================================
app.listen(port);
console.log('Magic happens at http://localhost:' + port);
module.exports = app;
