describe('nodetest', function() {

	beforeEach(module('bulkProcess'));

	var ctrl;


	beforeEach(inject(function(_$controller_) {
		ctrl = _$controller_;
		}));

	describe('Bulk upload controller', function() {
		it('check the properties', function() {
			var scp = {};
			var ctrl1 = ctrl('bulkCtrl', { $scope:scp });
			scp.name='ExtraProperties';
			scp.img='img/img1.jpg';
			scp.add();
			expect(scp.items.length).to.equal(5);
		});
	});
});
