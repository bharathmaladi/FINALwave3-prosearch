var express = require('express');
var router = express.Router();
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://10.219.85.125/smartSearchDb';var neo4j = require('neo4j-driver').v1;

router.get('/relation', function(req, res) {
	mongoClient.connect(url,function(err,db){
		    var cursor  =db.collection('ontologyRelations');
		    var sections=cursor.find().toArray(function(err, docs) {
		    res.json(docs);
		});
	});
});

module.exports = router;
