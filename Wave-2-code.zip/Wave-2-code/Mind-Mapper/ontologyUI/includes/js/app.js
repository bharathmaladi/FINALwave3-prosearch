var mindMap = angular.module('mindMap',['ngMaterial']);

mindMap.directive('graphDirective',function(){
  return {
    templateUrl : 'includes/views/graph.html',
    controller : 'DialogController'
  };
});


mindMap.directive('termDirective',function(){
  return {
    templateUrl : 'includes/views/term.html'
  };
});
