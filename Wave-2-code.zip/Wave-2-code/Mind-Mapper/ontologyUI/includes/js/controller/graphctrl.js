mindMap.controller('graphCtrl', function($scope, $mdDialog, $rootScope, $http,GetNameService, GetNodeService, PostNodeService, DeleteNodeService) {
    $scope.searchText = "";
    $scope.shows = false;
    $scope.searchGraphShow = false;
    $scope.alpha=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'];
    $scope.selectedItem = [];
    $scope.isDisabled = false;
    $scope.noCache = false;
    $scope.show = false;
    $scope.show1 = false;
    $scope.showsearch=false;
    $scope.msg = "";
    $scope.array = [];
    $scope.index=[];
    $scope.filter_show = true;
    $scope.data1 = {"nodes":[{"id":"11"}],"links":[{"source":"Fep"}]};
    $scope.data = {};
    $scope.orig_data = {};
    $scope.addshow=false;
    $scope.delshow=false;
    $scope.editshow=false;
    $scope.fabshow = false;
    $scope.graph2_show = false;

    $scope.selectedItemChange = function (item) {
        if ($scope.selectedItem)
          $scope.text=$scope.selectedItem.name;
        }
    $scope.searchTextChange = function (str) {
        return GetNameService.getName(str);
    }

    $scope.addshows=function(){
      $scope.addshow=true;
      $scope.shows=false;
      $scope.delshow=false;
      $scope.editshow=false;
      $scope.shows1=false;
    }
    $scope.delshows=function(){
      $scope.addshow=false;
      $scope.delshow=true;
      $scope.shows=false;
      $scope.editshow=false;
      $scope.shows1=false;
    }
    $scope.editshows=function(){
      $scope.editshow=true;
      $scope.addshow=false;
      $scope.delshow=false;
      $scope.shows=false;
      $scope.shows1=false;
    }

     GetNodeService.getNodes()
               .success(function (data, status, headers, config) {
                  $scope.data.nodes = data;

             });

    GetNodeService.getLinks()
                .success(function (data, status, headers, config) {
                   $scope.data.links = data;
            });
    GetNodeService.orig_nodes()
                .success(function (data, status, headers, config) {
                   $scope.orig_data.nodes= data;
            });
      GetNodeService.orig_links()
                  .success(function (data, status, headers, config) {
                     $scope.orig_data.links = data;
                     draworiggraph("graphDisplay",$scope.orig_data.nodes, $scope.orig_data.links);
              });

  PostNodeService.getRelation()
             .success(function (data, status, headers, config) {
                $scope.relations = data;
            });
$scope.orig_graph = function(){
    $scope.shows = true;
    $scope.shows1=false;
     $scope.searchGraphShow = false;
     console.log("gh");
}

$scope.graph = function(){
    var foo = d3.select("#searchedGraph");
    foo.remove();
    $scope.searchGraphShow = true;
    $scope.shows1 = false;
    $scope.src = "";
    $scope.shows = true;

    $scope.addshow=false;
    if(!$scope.hopcount)
      $scope.hopcount = 1;
    if($scope.text == null)
      $scope.fabshow = false;
    else
      $scope.fabshow = true;

          GetNodeService.getNodesGroup($scope.text,$scope.hopcount)
           .success(function (data, status, headers, config) {
                $scope.data1.nodes = data;

                 GetNodeService.getLinksId($scope.text,$scope.hopcount)
                  .success(function (data, status, headers, config) {
                    $scope.data1.links=data;
                    drawgraph("graphDisplay");
                    });

                 });

};//search_function_end


function drawgraph(graphdiv){
      var zoom = d3.zoom().scaleExtent([0.1	, 10]).on("zoom", zoomed);
      ok = [];
      tar_array = [];
      var foo = d3.select("#graph");
      foo.remove();
      var select = d3.select('#'+graphdiv);

      var svg = select.append("svg")
                .attr("width",960)
                .attr("height",400)
                .attr("id","graph")
                .call(zoom)
                .append("g")
                .attr("transform", "translate(450,150)");
                svg.style("cursor","hand");

      var width = +svg.attr("width"),
      height = +svg.attr("height");

      var color = d3.scaleOrdinal(d3.schemeCategory20);
      var simulation = d3.forceSimulation()
     .force("link", d3.forceLink().id(function(d) {return d.id}).distance(200))
     .force("collision", d3.forceCollide().radius(30))
     .force("gravity",d3.forceManyBody().strength(30))
     .force("center", d3.forceCenter(width/ 2, height / 2));

      var nodes_display = $scope.data1.nodes;
      var links_display = $scope.data1.links;
      // Define the div for the tooltip
      var div = d3.select("body").append("div")
                .attr("class", "tooltip")
                .style("opacity", 0);
     var ok = [];
     var flag = 0;
     var array = [];var src_array = [];var obj_array = [];
     var length = 0;
     var sub_obj = "OBJECT";
    var groupOfLinksAndNodes = svg.append("g");
    var groupLinks = groupOfLinksAndNodes.append("g").attr("class","links");
    var groupOfNodes = groupOfLinksAndNodes.append("g").attr("class", "nodes");
    var groupOfNodeElements = groupOfNodes.selectAll("g").data($scope.data1.nodes).enter().append("g")
      .on("dblclick", function(d){
        ok = [];
        tar_array = [];
        d3.select(this).select("circle").transition()
            .duration(750)
            // .attr("r", 36)
            .style("fill", "yellow")
            .style("stroke", "black");
            d3.select(this).select("text").transition()
                .duration(750)
                .attr("fill","black")
                .style("font-size", "20px")
                .style("font-family", "ariel");


        length=d.id.length; //node length
        for(i=0;i<links_display.length;i++){
          if(d.id ==links_display[i].source.id){
            sub_obj = "SUBJECT";
          }
          if(d.id ==links_display[i].target.id){
              sub_obj = "OBJECT";
            }
      }
      for(i=0;i<links_display.length;i++){

        if(d.id ==links_display[i].source.id){
          ok.push(links_display[i]);
        }
        if(d.id ==links_display[i].target.id){
          tar_array.push(links_display[i]);
        }

      }
          document.getElementById('para').innerHTML = "";
          if(flag!=0)
          for(i=0;i<ok.length;i++){
            var parent = document.getElementById("divpara1");
            parent.innerHTML = "";
          }
          if(sub_obj=="SUBJECT"){
            para = document.createElement("h6");
            node = document.createTextNode(ok[0].source.id+ " " +' \''+ok[0].relation+' \''+" " );
            para.appendChild(node);
            element = document.getElementById("divpara1");
            element.appendChild(para);
          }
          else{
            para = document.createElement("h6");
            node = document.createTextNode(tar_array[0].target.id+ " " +' \''+tar_array[0].relation+' \''+" " );
            para.appendChild(node);
            element = document.getElementById("divpara1");
            element.appendChild(para);
          }
      if(sub_obj=="SUBJECT"){
      var obj = [];
        for(i=0;i<ok.length;i++){
          obj.push(ok[i].target.id);
          para1 = document.createElement("li");
          node1 = document.createTextNode(ok[i].target.id);
          para1.appendChild(node1);

            element = document.getElementById("divpara1");
            element.appendChild(para1);

            element1 = document.getElementById("divpara");
            element1.appendChild(element);
            flag++;
          }


        }
          else{
            var obj = [];
            for(i=0;i<tar_array.length;i++){
            obj.push(tar_array[i].source.id);
            para1 = document.createElement("li");
            node1 = document.createTextNode(tar_array[i].source.id);
            para1.appendChild(node1);

              element = document.getElementById("divpara1");
              element.appendChild(para1);

              element1 = document.getElementById("divpara");
              element1.appendChild(element);
              flag++;
          }

        }



    })
            .call(d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended)
            )

            .call(d3.drag()
            .on("start", dragstarted)
            .on("drag", dragged)
            .on("end", dragended)
          )
          function zoomed() {
              svg.attr("transform", d3.event.transform.translate(450,150));
          }
    groupOfNodeElements.append("circle")
      .attr("r", 30)
      .attr("fill", function(d) { return color(d.group); })
    groupOfNodeElements.append("text")
      .text(function(d) {return d.id;})
        .attr("fill", "white");


    var link = groupLinks
      .selectAll("path")
      .data($scope.data1.links)
    	.enter().append("path")
      .attr("id",function(d,i){return 'edgepath'+i});

      simulation
        .nodes($scope.data1.nodes)
        .on("tick", ticked);
      simulation
        .force("link")
        .links(  $scope.data1.links)
    var nodeLabels = groupOfNodes
      .selectAll("text")
      .data($scope.data1.nodes)
      .enter().append("text")
      .text(function(d) { return d.value; })
      .attr("text-anchor","middle")

    var linkLabels = groupLinks
  		.selectAll("text")
  		.data($scope.data1.links)
  		.enter().append("text")
      .attr("fill","white")
      .on("dblclick", function(d){
          $scope.$emit("link_broadcast", {
           obj : d.source.id, obj_rel : d.relation, obj_tar: d.target.id
        })
        $scope.editshows();
      })

      .on("mouseover", function(d) {
          div.transition()
              .duration(200)
              .style("opacity", .9);
          div	.html("<p>Double Click to edit properties</p>")
              .style("left", (d3.event.pageX) + "px")
              .style("top", (d3.event.pageY - 28) + "px");
          })
      .on("mouseout", function(d) {
          div.transition()
              .duration(500)
              .style("opacity", 0);
      })

      .attr("x", 60)
      .append("textPath")
        .attr("class", "textpath")
        .attr("xlink:href", function(d,i) {return '#edgepath'+i})
        .text(function(d) { return (d.relation) });


      function ticked() {
        link.attr("d", function(d) {
          dx = d.target.x - d.source.x;
          dy = d.target.y - d.source.y;
          dr = Math.sqrt(dx*dx + dy*dy);
          return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
        })


      // link
      // 	.attr("x1", function(d) {return d.source.x;})
      // 	.attr("y1", function(d) {return d.source.y;})
      // 	.attr("x2", function(d) {return d.target.x;})
      // 	.attr("y2", function(d) {return d.target.y;})
      groupOfNodes
        .selectAll("circle")
        .attr("cx", function(d) {return d.x;})
        .attr("cy", function(d) {return d.y;})
      groupOfNodes
        .selectAll("text")
        .attr("x", function(d) { return d.x - 20 })
        .attr("y", function(d) { return d.y; });
      // linkLabels
      // 	.attr("x", function(d) { return (d.source.x + d.target.x) / 2; })
      // 	.attr("y", function(d) { return (d.source.y + d.target.y) / 2; })
      nodeLabels
        .attr("x",function(d) {return d.x})
        .attr("y",function(d) {return d.y})
    }
    //graphone

    function dragstarted(d) {
    if (!d3.event.active) simulation.alphaTarget(0.3).restart();
    d.fx = d.x;
    d.fy = d.y;
    }

    function dragged(d) {
    d.fx = d3.event.x;
    d.fy = d3.event.y;
    }

    function dragended(d) {
    // if (!d3.event.active) simulation.alphaTarget(0);
    // d.fx = null;
    // d.fy = null;
    d.fixed = true;
    // simulation.restart();
    }
  }//graphdraw func
//terms
$scope.term=function(s){
  var required_term=s.toLowerCase();
  $scope.display_terms = " ";
  $scope.shows1=true;
  $scope.shows=false;
  $scope.editshow=false;
  $scope.addshow=false;
  $scope.delshow=false;
  $scope.terms = [];
  var terms_data=[];
GetNodeService.getTerms(required_term).success(function(data){
  terms_data=data;
  for(i=0;i<terms_data.length;i++)
  {
  if(terms_data[i].name.charAt(0)==required_term)
      $scope.terms.push(terms_data[i].name);
  }
  if($scope.terms == null)
    $scope.display_terms = "No data starting with ";
});

}

$scope.displayTerm = function(term){
  $scope.text = term;
  if(!$scope.hopcount)
    $scope.hopcount = 1;
    GetNodeService.getNodesGroup($scope.text,$scope.hopcount)
     .success(function (data, status, headers, config) {
          $scope.data1.nodes = data;
           GetNodeService.getLinksId($scope.text,$scope.hopcount)
            .success(function (data, status, headers, config) {
              $scope.data1.links=data;
              drawgraph("graphtermsdisplay");
              });

           });


  }//display_term end
//
                    <!-- broadcasting among controllers-->

$scope.$on("capture",function(event,args){
var obj = {};

  $scope.flag=0;
  var target=args.tar;
  if( ($scope.data.nodes.indexOf(target) )>=0){

    GetNodeService.getRelationName(args.src, args.tar, args.label).success(function(data){
      $scope.rel=data;
      if($scope.rel!="null"){
          if($scope.rel==args.rel){
              $scope.flag=2;
              obj['source']=args.src;obj['target']=args.tar;
              obj['label']=args.label;obj['relation']=args.rel;
              obj['flag']=$scope.flag;obj['properties']=args.key_object;
              var objstr=JSON.stringify(obj);
              PostNodeService.postNodes(objstr)
              .success(function(data, status, headers, config) {
                });
                window.location.reload();
                window.alert("Node added successfully");
            }
            else{
                $scope.flag=1;
                obj['source']=args.src;obj['target']=args.tar;
                obj['label']=args.label;obj['relation']=args.rel;
                obj['flag']=$scope.flag;obj['properties']=args.key_object;
                var objstr=JSON.stringify(obj);
                PostNodeService.postNodes(objstr)
                .success(function(data, status, headers, config) {
                  });
                  window.location.reload();
                  window.alert("Node added successfully");
            }
          }
          else{
              $scope.flag=1;
              obj['source']=args.src;obj['target']=args.tar;
              obj['label']=args.label;obj['relation']=args.rel;
              obj['flag']=$scope.flag;obj['properties']=args.key_object;
              var objstr=JSON.stringify(obj);
              PostNodeService.postNodes(objstr)
              .success(function(data, status, headers, config) {
                });
                window.location.reload();
                window.alert("Node added successfully");
          }
    })
}
else{
  obj['source']=args.src;obj['target']=args.tar;
  obj['label']=args.label;obj['relation']=args.rel;
  obj['flag']=$scope.flag;obj['properties']=args.key_object;
  var objstr=JSON.stringify(obj);
  PostNodeService.postNodes(objstr)
  .success(function(data, status, headers, config) {
    });
    window.alert("Node added successfully !!");
    window.location.reload();
}



  // window.location.reload();
});

$scope.$on("newNode_capture",function(event,args){
  if( ($scope.data.nodes.indexOf(args.src) )>=0)
     window.alert(args.src+" already exists, Use Existing node provision");

  else if(($scope.data.nodes.indexOf(args.tar))>=0)
      window.alert(args.tar+" already exists, Use Existing node provision");
  else{
    var obj = {};
    obj['source']=args.src;obj['target']=args.tar;
    obj['label']=args.label;obj['relation']=args.rel;
    obj['properties']=args.properties;
    var objstr=JSON.stringify(obj);
    PostNodeService.postNewNodes(objstr)
    .success(function(data, status, headers, config) {
    });
    window.alert("Node added successfully !!");
    window.location.reload();
}
});


//del broadcast
$scope.$on("del_capture",function(event,args){

for(var i=0;i<$scope.data.nodes.length;i++)
  if(args.del == $scope.data.nodes[i])
  {
      DeleteNodeService.deleteNodes(args.del).success(function(data){
        });
  }
  window.alert("Node deleted successfully !!");
  window.location.reload();
});//del_end

});//Controller End
