mindMap.controller('drawGraph', function ($scope, $rootScope){
  $scope.edit_value = "";
var transform = d3.zoomIdentity;
// $scope.$on("new_node",function(event,args){
//   d3.select('#graph').remove();
//   var select = d3.select('#graphDisplay');
//                  var svg = select.append("svg")
//                       .attr("width",460)
//                       .attr("height",400)
//                       .attr("id","graph");
//   drawGraph("graph","includes/data/graphdata.json");
// });
  drawGraph("graph","includes/data/graphdata.json");

  function drawGraph(graphId, datafileName){
    var select = d3.select("#"+graphId);
    var svg = select.append("svg")
    			.attr("id", "graph")
          .attr("width",900)
          .attr("height",600)
    			.call(zoom)
    			.append("g")
    			.attr("transform", "translate(450,150)");

  var width = +svg.attr("width"),
    	height = +svg.attr("height");


  var color = d3.scaleOrdinal(d3.schemeCategory20);
  var simulation = d3.forceSimulation()
  	.force("link", d3.forceLink().id(function(d) {return d.id}).distance(200))
  	.force("collision", d3.forceCollide().radius(30))
  	.force("gravity",d3.forceManyBody().strength(30))
  	.force("center", d3.forceCenter(width/ 2, height / 2));


  d3.json(datafileName, function(error,graph1) {
  	if(error) throw error;
  	var nodes_display = graph1.nodes;
  	var links_display = graph1.links;
    var ok = [];
    var tar_array = [];
  	var flag = 0;
  	var array = [];var src_array = [];var obj_array = [];
  	var length = 0;
  	var sub_obj = "OBJECT";
  	var groupOfLinksAndNodes = svg.append("g");
  	var groupLinks = groupOfLinksAndNodes.append("g").attr("class","links");
  	var groupOfNodes = groupOfLinksAndNodes.append("g").attr("class", "nodes");
  	var groupOfNodeElements = groupOfNodes.selectAll("g").data(graph1.nodes).enter().append("g")

  	.on("click", function(d,i){
      $scope.edit_value = d.id;
  		d3.select(this).select("circle").transition()
          .duration(750)
          .style("fill", "white")
  				.style("stroke", "black");
  				d3.select(this).select("text").transition()
  						.duration(750)
  						.style("font-size", "20px")
  						.style("font-family", "ariel");
  		ok = [];
      tar_array = [];
  		length=d.id.length; //node length
  		for(i=0;i<links_display.length;i++){
  			if(d.id ==links_display[i].source.id){
  				sub_obj = "SUBJECT";
  			}
  			if(d.id ==links_display[i].target.id){
  					sub_obj = "OBJECT";
  				}
  	}
  	for(i=0;i<links_display.length;i++){
  		if(d.id ==links_display[i].source.id){
  			ok.push(links_display[i]);
  		}
      if(d.id ==links_display[i].target.id){
  			tar_array.push(links_display[i]);
  		}
  }
  			document.getElementById('para').innerHTML = "";
  			if(flag!=0)
  			for(i=0;i<ok.length;i++){
  				var parent = document.getElementById("divpara1");
  				parent.innerHTML = "";
  			}
        if(sub_obj=="SUBJECT"){
  				para = document.createElement("h4");
  				node = document.createTextNode(ok[0].source.id+ " " +' \''+ok[0].relation+' \''+" " );
  				para.appendChild(node);
  				element = document.getElementById("divpara1");
  				element.appendChild(para);
        }
        else{
          para = document.createElement("h4");
  				node = document.createTextNode(tar_array[0].target.id+ " " +' \''+tar_array[0].relation+' \''+" " );
  				para.appendChild(node);
  				element = document.getElementById("divpara1");
  				element.appendChild(para);
        }
  if(sub_obj=="SUBJECT"){
    var obj = [];
      for(i=0;i<ok.length;i++){
        obj.push(ok[i].target.id);
    		para1 = document.createElement("li");
  			node1 = document.createTextNode(ok[i].target.id);
  			para1.appendChild(node1);

  			  element = document.getElementById("divpara1");
  				element.appendChild(para1);

  				element1 = document.getElementById("divpara");
  				element1.appendChild(element);
  				flag++;
        }
      }
        else{
          var obj = [];
          for(i=0;i<tar_array.length;i++){
          obj.push(tar_array[i].source.id);
          para1 = document.createElement("li");
    			node1 = document.createTextNode(tar_array[i].source.id);
    			para1.appendChild(node1);

    			  element = document.getElementById("divpara1");
    				element.appendChild(para1);

    				element1 = document.getElementById("divpara");
    				element1.appendChild(element);
    				flag++;
        }
      }
  	})
  					.call(d3.drag()
  					.on("start", dragstarted)
  					.on("drag", dragged)
  					.on("end", dragended)
  					)

  	groupOfNodeElements.append("circle")
  		.attr("r", 5)
  		.attr("fill", function(d) { return color(d.group); })

  	groupOfNodeElements.append("text")
  		.text(function(d) {return d.id;})
        .attr("id",function(d,i) {return 'textwrap'+i});

    var link = groupLinks
  		.selectAll("path")
  		.data(graph1.links)
  		.enter().append("path").attr("id",function(d,i){return 'edgepath'+i});

  		simulation
  			.nodes(graph1.nodes)
  			.on("tick", ticked);
  		simulation
  			.force("link")
  			.links(graph1.links)

  	var nodeLabels = groupOfNodes
  		.selectAll("text")
  		.data(graph1.nodes)
  		// .enter().append("text")
  		// .text("hi")
  		.attr("text-anchor","middle")

  	var linkLabels = groupLinks
  		.selectAll("text")
  		.data(graph1.links)
  		.enter().append("text")
      .attr("x", 60)
      .append("textPath")
        .attr("class", "textpath")
        .attr("xlink:href", function(d,i) {return '#edgepath'+i})
        .text(function(d) { return (d.relation) });

  		function ticked() {
  			link.attr("d", function(d) {
  				dx = d.target.x - d.source.x;
  				dy = d.target.y - d.source.y;
  				dr = Math.sqrt(dx*dx + dy*dy);
  				return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
  			})
  		groupOfNodes
  			.selectAll("circle")
  			.attr("cx", function(d) {return d.x;})
  			.attr("cy", function(d) {return d.y;})
  		groupOfNodes
  			.selectAll("text")
  			.attr("x", function(d) { return d.x; })
  			.attr("y", function(d) { return d.y; });
  		// linkLabels
  		// 	.attr("x", 200)
  		// 	.attr("y", 200)
  		nodeLabels
  			.attr("x",function(d) {return d.x})
  			.attr("y",function(d) {return d.y})
  	}


  });

  //graphone
  function dragstarted(d) {
  	if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  	d.fx = d.x;
  	d.fy = d.y;
  }

  function dragged(d) {
  	d.fx = d3.event.x;
  	d.fy = d3.event.y;
  }

  function dragended(d) {
  	if (!d3.event.active) simulation.alphaTarget(0);
  	// d.fx = null;
  	// d.fy = null;
  	d.fixed = true;
    }
}
});
