// mindMap.controller('graphCtrl', function($scope) {

function draworiggraph(graphdiv,nodes,links){
  var zoom = d3.zoom().scaleExtent([0.1	, 10]).on("zoom", zoomed);
  ok = [];
  tar_array = [];
  var foo = d3.select("#graph");
  foo.remove();
  var select = d3.select('#'+graphdiv);

  var svg = select.append("svg")
            .attr("width",960)
            .attr("height",550)
            .attr("id","graph")
            .call(zoom)
            .append("g")
            .attr("transform", "translate(350,250)");
            svg.style("cursor","hand");

  // var width = svg.attr("width"),
  // height    =    svg.attr("height");


  var color = d3.scaleOrdinal(d3.schemeCategory20);
  var simulation = d3.forceSimulation()
  .force("link", d3.forceLink().id(function(d) {return d.id}).distance(200))
  .force("collision", d3.forceCollide().radius(50))
  .force("gravity",d3.forceManyBody().strength(80))
  .force("center", d3.forceCenter(900/6, 400 / 6));

  var nodes_display = nodes;
  var links_display = links;
  // Define the div for the tooltip
  var div = d3.select("body").append("div")
            .attr("class", "tooltip")
            .style("opacity", 0);
  var ok = [];
  var flag = 0;
  var array = [];var src_array = [];var obj_array = [];
  var length = 0;
  var sub_obj = "OBJECT";
  var groupOfLinksAndNodes = svg.append("g");
  var groupLinks = groupOfLinksAndNodes.append("g").attr("class","links");
  var groupOfNodes = groupOfLinksAndNodes.append("g").attr("class", "nodes");
  var groupOfNodeElements = groupOfNodes.selectAll("g").data(nodes).enter().append("g")
  .on("dblclick", function(d){
    ok = [];
    tar_array = [];
    d3.select(this).select("circle").transition()
        .duration(750)
        // .attr("r", 36)
        .style("fill", "yellow")
        .style("stroke", "black");
        d3.select(this).select("text").transition()
            .duration(750)
            .attr("fill","black")
            .style("font-size", "20px")
            .style("font-family", "ariel");


    length=d.id.length; //node length
    for(i=0;i<links_display.length;i++){
      if(d.id ==links_display[i].source.id){
        sub_obj = "SUBJECT";
      }
      if(d.id ==links_display[i].target.id){
          sub_obj = "OBJECT";
        }
  }
  for(i=0;i<links_display.length;i++){

    if(d.id ==links_display[i].source.id){
      ok.push(links_display[i]);
    }
    if(d.id ==links_display[i].target.id){
      tar_array.push(links_display[i]);
    }

  }
      document.getElementById('para').innerHTML = "";
      if(flag!=0)
      for(i=0;i<ok.length;i++){
        var parent = document.getElementById("divpara1");
        parent.innerHTML = "";
      }
      if(sub_obj=="SUBJECT"){
        para = document.createElement("h6");
        node = document.createTextNode(ok[0].source.id+ " " +' \''+ok[0].relation+' \''+" " );
        para.appendChild(node);
        element = document.getElementById("divpara1");
        element.appendChild(para);
      }
      else{
        para = document.createElement("h6");
        node = document.createTextNode(tar_array[0].target.id+ " " +' \''+tar_array[0].relation+' \''+" " );
        para.appendChild(node);
        element = document.getElementById("divpara1");
        element.appendChild(para);
      }
  if(sub_obj=="SUBJECT"){
  var obj = [];
    for(i=0;i<ok.length;i++){
      obj.push(ok[i].target.id);
      para1 = document.createElement("li");
      node1 = document.createTextNode(ok[i].target.id);
      para1.appendChild(node1);

        element = document.getElementById("divpara1");
        element.appendChild(para1);

        element1 = document.getElementById("divpara");
        element1.appendChild(element);
        flag++;
      }


    }
      else{
        var obj = [];
        for(i=0;i<tar_array.length;i++){
        obj.push(tar_array[i].source.id);
        para1 = document.createElement("li");
        node1 = document.createTextNode(tar_array[i].source.id);
        para1.appendChild(node1);

          element = document.getElementById("divpara1");
          element.appendChild(para1);

          element1 = document.getElementById("divpara");
          element1.appendChild(element);
          flag++;
      }

    }



  })
        .call(d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended)
        )

        .call(d3.drag()
        .on("start", dragstarted)
        .on("drag", dragged)
        .on("end", dragended)
      )
      function zoomed() {
          svg.attr("transform", d3.event.transform.translate(450,150));
      }
  groupOfNodeElements.append("circle")
  .attr("r", 30)
  .attr("fill", function(d) { return color(d.group); })
  groupOfNodeElements.append("text")
  .text(function(d) {return d.id;})
    .attr("fill", "white");


  var link = groupLinks
  .selectAll("path")
  .data(links)
  .enter().append("path")
  .attr("id",function(d,i){return 'edgepath'+i});

  simulation
    .nodes(nodes)
    .on("tick", ticked);
  simulation
    .force("link")
    .links( links)
  var nodeLabels = groupOfNodes
  .selectAll("text")
  .data(nodes)
  .enter().append("text")
  .text(function(d) { return d.value; })
  .attr("text-anchor","middle")

  var linkLabels = groupLinks
  .selectAll("text")
  .data(links)
  .enter().append("text")
  .attr("fill","white")
  .on("dblclick", function(d){
      $rootScope.$emit("link_broadcast", {
       obj : d.source.id, obj_rel : d.relation, obj_tar: d.target.id
    })
    $rootScope.editshows();
  })

  .on("mouseover", function(d) {
      div.transition()
          .duration(200)
          .style("opacity", .9);
      div	.html("<p>Click to edit properties</p>")
          .style("left", (d3.event.pageX) + "px")
          .style("top", (d3.event.pageY - 28) + "px");
      })
  .on("mouseout", function(d) {
      div.transition()
          .duration(500)
          .style("opacity", 0);
  })

  .attr("x", 60)
  .append("textPath")
    .attr("class", "textpath")
    .attr("xlink:href", function(d,i) {return '#edgepath'+i})
    .text(function(d) { return (d.relation) });


  function ticked() {
    link.attr("d", function(d) {
      dx = d.target.x - d.source.x;
      dy = d.target.y - d.source.y;
      dr = Math.sqrt(dx*dx + dy*dy);
      return "M" + d.source.x + "," + d.source.y + "A" + dr + "," + dr + " 0 0,1 " + d.target.x + "," + d.target.y;
    })


  // link
  // 	.attr("x1", function(d) {return d.source.x;})
  // 	.attr("y1", function(d) {return d.source.y;})
  // 	.attr("x2", function(d) {return d.target.x;})
  // 	.attr("y2", function(d) {return d.target.y;})
  groupOfNodes
    .selectAll("circle")
    .attr("cx", function(d) {return d.x;})
    .attr("cy", function(d) {return d.y;})
  groupOfNodes
    .selectAll("text")
    .attr("x", function(d) { return d.x - 20 })
    .attr("y", function(d) { return d.y; });
  // linkLabels
  // 	.attr("x", function(d) { return (d.source.x + d.target.x) / 2; })
  // 	.attr("y", function(d) { return (d.source.y + d.target.y) / 2; })
  nodeLabels
    .attr("x",function(d) {return d.x})
    .attr("y",function(d) {return d.y})
  }
  //graphone

  function dragstarted(d) {
  if (!d3.event.active) simulation.alphaTarget(0.3).restart();
  d.fx = d.x;
  d.fy = d.y;
  }

  function dragged(d) {
  d.fx = d3.event.x;
  d.fy = d3.event.y;
  }

  function dragended(d) {
  // if (!d3.event.active) simulation.alphaTarget(0);
  // d.fx = null;
  // d.fy = null;
  d.fixed = true;
  // simulation.restart();
  }
  }//graphdraw func
// });
