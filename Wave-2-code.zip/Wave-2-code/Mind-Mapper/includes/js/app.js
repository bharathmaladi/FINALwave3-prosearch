angular.module('searchPortal',['ngMaterial']).controller('appctrl',function($scope){

});
