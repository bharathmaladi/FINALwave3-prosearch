var mindMap = angular.module('mindMap',['ngMaterial','ui.router','xeditable','ngAnimate']);

// ---------------- ^^^ Config ^^^ --------------------------
mindMap.config(function($stateProvider,$urlRouterProvider){
  $stateProvider
    .state('home',{
      url: '',
      templateUrl:'includes/components/views/queryBuild/queryBuild_tmpl.html'
    })

    .state('savedQuery',{
          templateUrl:'includes/components/views/savedQueryView/savedQueries_tmpl.html',
          controller : "savedQuery"
    })

    .state('builder',{
      templateUrl:'includes/components/views/active/active_tmpl.html'
    })

    .state('builder.search',{
      params: {
        profiles: null
      },
      views : {
        'builderToggle': {
          templateUrl:'includes/components/views/searchResultsView/searchResults_tmpl.html',
          controller:'searchDisplay'
        }
      }
    })

    .state('builder.graph',{
      params: {
        value: null
      },
      views : {
        'builderToggle': {
          templateUrl:'includes/components/views/graphView/graph_tmpl.html',
          controller: 'graphCtrl'
        }
      }
    })
});

mindMap.run(function(getAppToken,$rootScope) {
  getAppToken.getToken().success(function(token){
    $rootScope.appToken = token;
  });
});
