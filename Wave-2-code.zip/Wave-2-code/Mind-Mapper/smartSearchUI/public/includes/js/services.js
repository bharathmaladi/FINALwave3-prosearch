mindMap.service('GetProfiles', function($http){
    this.getProfile = function(searchQuery){
     return  $http.post('api/searchresults',searchQuery);
    }
});


mindMap.service('GetRelation',function($http){
  this.getRelation = function() {
    return $http.get('api/relations');
  }
});

mindMap.service('GetNodeService',function($http){
  this.getNodesGroup = function(text,hop) {
              return $http.get('api/searched_nodes/'+text+'/'+hop)
        }
  this.getLinksId = function(text,hop) {
        return $http.get('api/searched_links/'+text+'/'+hop)
  }
});

mindMap.service('GetGraphLinks', function($http){
    this.getLinks = function(){
     return  $http.get('api/links');
    }
});

mindMap.service('getAppToken', function($http){
    this.getToken = function(){
     return  $http.get('');
    }
});

mindMap.service('GetGraphNodes', function($http){
    this.getNodes = function(){
     return  $http.get('api/nodes');
    }
});

mindMap.service('saveTheQuery', function($http){
  this.save = function(data){
    return $http.post('api/query/',data);
  }
});

mindMap.service('getSavedQueries', function($http){
  this.getQuery = function(){
    return $http.get('api/query');
  }
});

mindMap.service('validateQuery', function($http){
  this.getQuery = function(data){
    return $http.get('api/queryname/'+ data);
  }
});

mindMap.service('deleteQuery', function($http){
  this.deleteIt = function(data){
    return $http.post("api/queryname",data);
  }
});
