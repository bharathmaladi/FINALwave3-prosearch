describe('addFilterTest', function(){

  beforeEach(module('mindMap'));

  var $controller;
  var $scope = {};

	beforeEach(inject(function(_$controller_) {
		$controller = _$controller_;
    var controller = $controller('addFilter', { $scope:$scope });
	}));

  describe('Generating Autocomplete Values', function(){
    
  });

	describe('Trigger functions', function() {

		it('Testing Value Trigger', function() {
			expect($scope.isDisabled).to.equal(false);
		});

    it('Testing Criteria Trigger', function() {
			expect($scope.isDisabled).to.equal(false);
		});

    it('Testing Relation Trigger', function() {
			expect($scope.isDisabled).to.equal(false);
		});

    it('Testing AndOr Trigger', function() {
			expect($scope.isDisabled).to.equal(false);
		});

	});


});
