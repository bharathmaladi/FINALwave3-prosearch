describe('Filter Result card', function() {
   beforeEach(module('mindMap'));
   var $controller;
   var $scope = {},$rootScope;
   beforeEach(inject(function(_$controller_,_$rootScope_) {
      $controller = _$controller_;
      $rootScope = _$rootScope_;
      $controller('queryDisplayCtrl',{$scope:{},$rootScope: $rootScope})
      var controller = $controller('filterResultCard', { $scope:$scope, $rootScope: $rootScope });
   }));

   describe('Button Functions', function() {
       it('AddFilter', function() {
         $rootScope.filterArray = [{},{}];
         $scope.increment = 1;
           var myobj = {             'criteriaVal' : null,
                                     'relationVal' : null,
                                     'valueVal' : null,
                                     'index' : 1,
                                     'andOrVal' : null,
                                     'query': null
                                   };
           $scope.addFilter(2);
           expect($rootScope.filterArray).not.equal('');
           expect($rootScope.filterArray[2]).to.deep.equal(myobj);
       });

       it('Remove Filter', function() {
           $rootScope.filterArray=[{},{}];
           $scope.increment = 1;
           $scope.removeFilter(1);
           expect($rootScope.filterArray.length).to.equal(1);
       });
   });

});
