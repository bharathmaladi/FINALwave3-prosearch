mindMap.directive('searchResultCard',function(){
  return {
    templateUrl : "includes/components/directives/searchResultCardDir/searchResultCard_tmpl.html"
  }
});
