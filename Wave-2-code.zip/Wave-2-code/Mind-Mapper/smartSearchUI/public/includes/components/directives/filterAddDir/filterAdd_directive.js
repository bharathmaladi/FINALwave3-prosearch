mindMap.directive('filterAdd',function(){
  return {
    scope: {
      searchQuery: '='
    },
    templateUrl : "includes/components/directives/filterAddDir/filterAdd_tmpl.html",
    controller : "addFilter"
  }
});
