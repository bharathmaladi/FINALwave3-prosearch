mindMap.controller('mainCtrl',function($scope,$state,$rootScope,$http,$mdDialog,GetProfiles){

  $scope.searchQuery  = [{
                      'openP': '',
                      'relationVal' : 'employed_at',
                      'valueVal' : 'cognizant',
                      'closeP': '',
                      'operator' : ''
                      }];

  // ---------------- ^^^ Search Button ^^^ --------------------------
  $scope.search = function (){
    GetProfiles.getProfile($scope.searchQuery).success(function(profiles) {
      $state.transitionTo('builder.search',{profiles:profiles});
    })
  };

  // ---------------- ^^^ View Query Button ^^^ --------------------------
  $scope.savedQuery = function(){
    $state.transitionTo('savedQuery');
  };

  // ---------------- ^^^ Save Query Button ^^^ --------------------------
  $scope.showSaveQueryTab = function(){
    $mdDialog.show({
      locals:{queryData: $scope.searchQuery},
      templateUrl : "includes/components/dialogs/saveQueryDialog/saveQuery_Dialog.html",
      clickOutsideToClose:true,
      controller: "saveQueryDialog"
    });
  };
});
