mindMap.controller('savedQuery', function($scope,$rootScope,$state,getSavedQueries,deleteQuery){
  $scope.savedqueries = [];

  getSavedQueries.getQuery().success(function(response){
    $scope.savedqueries = response;

    $scope.editQuery = function(index){
      $rootScope.searchQuery = $scope.savedqueries[index].query;
      $state.transitionTo('builder.search');
    };

    $scope.deleteQuery = function(index){
      var temp = {"queryName": null};
      var deleteQueryName = $scope.savedqueries[index].queryName;
      temp.queryName = deleteQueryName;
      deleteQuery.deleteIt(temp);
      getSavedQueries.getQuery().success(function(response){
        $scope.savedqueries = response;
      });
    };
  });


});
