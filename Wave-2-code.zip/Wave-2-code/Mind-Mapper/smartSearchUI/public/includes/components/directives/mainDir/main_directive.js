mindMap.directive('mainDir',function(){
  return {
    templateUrl : "includes/components/directives/mainDir/main_tmpl.html",
    controller : "mainCtrl"
  }
});
