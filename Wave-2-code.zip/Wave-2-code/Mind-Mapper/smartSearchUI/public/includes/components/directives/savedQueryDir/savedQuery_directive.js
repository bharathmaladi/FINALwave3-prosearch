mindMap.directive('savedQuery',function(){
  return {
    templateUrl : "includes/components/directives/savedQueryDir/savedQuery_tmpl.html"
  }
});
