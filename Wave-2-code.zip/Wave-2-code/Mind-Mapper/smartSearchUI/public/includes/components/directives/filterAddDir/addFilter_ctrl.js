// ---------------- ^^^ Add Filter Ctrl ^^^ --------------------------
mindMap.controller("addFilter",function($scope,$rootScope,$stateParams,GetRelation,$state,GetNodeService){
  $scope.criteriaText = "";
  $scope.criteria = [];
  $scope.selectedCriteria = [];
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.space = " ";
  $scope.andOrArr = [ "and" , "or"];

  $scope.filters = $scope.searchQuery;
  if($stateParams.query != null){
    $scope.filters = $stateParams.query;
  }

  $scope.searchText = "";
  $scope.Person = [];
  $scope.selectedRelation = [];
  $scope.isDisabled = false;
  $scope.noCache = false;
  $scope.relations = [];
  $scope.valueIn = "Cognizant"

  GetRelation.getRelation().success(function(relation){
    // for (var i = 0 ; i < relation.length ; i++){
    //   var temp = relation[i].split("_");
    //   $scope.relations[i] = temp.join(" ").toLowerCase();
    // }
    $scope.relations = relation;

    $scope.showRelations = function (x) {
      var elementId = '#relPopUp' + x;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.removeClass("ng-hide");
    }

    $scope.showValueInput = function (x) {
      var elementId = '#valPopUp' + x;
      var focuselem = '#focusOn' + x;
      var expEl = angular.element( document.querySelector(elementId) );
      var doFocus = angular.element( document.querySelector(focuselem) );
      expEl.removeClass("ng-hide");
      doFocus.focus();
    }

    $scope.selectCurrentRelation = function(index, parent) {
      $scope.filters[parent].relationVal = $scope.relations[index];
      var elementId = '#relPopUp' + parent;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }

    $scope.enterDetect = function(key, index, value){
      if(key.which === 13){
        $scope.filters[index].valueVal = value;
        var elementId = '#valPopUp' + index;
        var expEl = angular.element( document.querySelector(elementId) );
        expEl.addClass("ng-hide");
      }
    }

    $scope.selectValue = function(index, value){
      if (value != null && value != ''){
        $scope.filters[index].valueVal = value;
      }
      var elementId = '#valPopUp' + index;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }

    $scope.cancelValue = function (index){
      var elementId = '#valPopUp' + index;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }

    $scope.cancelRel = function(index){
      var elementId = '#relPopUp' + index;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }

    $scope.cancelAndOr = function(index){
      var elementId = '#andOrPopUp' + index;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }

    $scope.showAndOr = function(index){
      var elementId = '#andOrPopUp' + index;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.removeClass("ng-hide");
    }

    $scope.selectCurrentAndOr = function(index,parent){
      $scope.filters[parent].operator = $scope.andOrArr[index];
      var elementId = '#andOrPopUp' + parent;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }



    $scope.showGraph = function(value, id, index){
      $state.transitionTo('builder.graph',{value:value});
      var elementId = '#valPopUp' + index;
      var expEl = angular.element( document.querySelector(elementId) );
      expEl.addClass("ng-hide");
    }




  });

  // ---------------- ^^^ Trigger Functions ^^^ --------------------------
  $scope.showAdd = function(index){
    if (index == ($scope.filters.length - 1)) return true;
    return false;
  };



  $scope.showAndOrField = function(index){
    if (index == ($scope.filters.length - 1)) return false;
    return true;
  };

  $scope.addFilter = function(index){
      $scope.filters[index].operator = 'and';
      $scope.filters.push({
                                'openP': '',
                                'relationVal' : 'employed_at',
                                'valueVal' : 'cognizant',
                                'closeP': '',
                                'operator' : ''
                              });
    };

    $scope.removeFilter = function (x){
      if (x == ($scope.filters.length-1)){
        $scope.filters[x-1].operator = '';
      }
      var idInd = $scope.filters.length;
      if((x+1) == idInd) {
        var temp = (x-1);
        var btnId = '#addBtn' + temp;
        var addBtn = angular.element( document.querySelector(btnId) );
        addBtn.removeClass("ng-hide");
      }
      $scope.filters.splice(x,1);
    }



});
