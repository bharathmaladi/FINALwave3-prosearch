mindMap.controller('searchDisplay', function($scope,$stateParams){
  $scope.profiles = [];
  $scope.profiles = $stateParams.profiles;

  $scope.viewProfile = function(index){
    var profileId = $scope.profiles[index].userId;
    
  }
});
