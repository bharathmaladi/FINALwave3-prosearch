mindMap.controller('saveQueryDialog', function($scope,$rootScope,queryData,saveTheQuery,$mdDialog,validateQuery){
  $scope.showExistAlert = false;
  $scope.queryData = queryData;
  $scope.newQuery = function (){
    this.userName = '',
    this.queryName = '',
    this.description = '',
    this.query = []
  };

  $scope.saveQuery = function(details){
    var query = new $scope.newQuery();
    query.userName = details.userName;
    query.queryName = details.queryName;
    query.description = details.description;
    query.query = $scope.queryData;

    var json = angular.toJson(query);

    validateQuery.getQuery(details.queryName).success(function(response){
        if (response.length){
          $scope.showExistAlert = true;
        } else {
          saveTheQuery.save(json);
          $mdDialog.cancel();
        }
    });
  };

  $scope.cancelSave = function(){
    $mdDialog.cancel();
  };
});
