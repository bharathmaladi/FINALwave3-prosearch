var express = require('express');
var router = express.Router();

router.post('/query',function(req,res){
        var query = req.body;
        var cursor = db.collection('queryBuilder');
        cursor.insert(query);
        res.send("success");
});

module.exports = router;
