var express = require('express');
var router = express.Router();
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.125", neo4j.auth.basic("neo4j", "password"));
var session = driver.session();
var Promise = require('promise');
var nlp = require('nlp_compromise');
var objectPath = require('object-path');

router.post('/searchresults', function(req,res) {
  var query = "MATCH ";
  var where= "WHERE ";
  var searchExpression = req.body;
  searchExpression.forEach(function(expression,index) {
    var relation = "r"+index;
    var criteria = "criteria"+index;
    expression.valueVal = nlp.term(expression.valueVal).normalize()
    query += "(user:Profile)-["+relation+"]-("+criteria+"),";
    where += expression.openP + relation + ".relationName ='" + expression.relationVal + "' AND " + criteria + ".term ='" + expression.valueVal + "'"+expression.closeP+" "+expression.operator +" ";
  });
  query = query.substring(0, query.length-1);
  query += " "+ where + " return user";
  console.log(query);

  session.run(query).then(function(result) {
      var results = [];
      var searchedObjId = [];
      result.records.forEach(function(record) {
        searchedObjId.push(record._fields[0].properties.id);
      });
      var arrayStr = "'" + searchedObjId.join("','") + "'";
      var arrayStr = "[" + arrayStr + "]";
      var resultsQuery = "MATCH (z:skills)-[r]-(n:Profile)-[r1]-(x:location) where type(r) in ['has_learnt','has_experience_with'] and n.id in " + arrayStr +" and type(r1) in ['Worked','stay','Used_To_Stay'] WITH n, collect(DISTINCT z) as skills ,x OPTIONAL match (n)-[r3]-(y:organization) where type(r3) in ['employee_at','employed_at'] WITH  n as user,skills,collect(DISTINCT x) as org,collect(DISTINCT y) as locations return user,skills,org,locations";
      session.run(resultsQuery).then(function(details){
        details.records.forEach(function(record){
          var tempObj = {'name':'','organisation':'','skills':[],'location':'','userId':''};
          tempObj.name = record._fields[0].properties.name;
          tempObj.userId = record._fields[0].properties.id;
          objectPath.ensureExists(record,'_fields.1',[]);
          record._fields[1].forEach(function(skill){
            tempObj.skills.push(skill.properties.term);
          })
          objectPath.ensureExists(record,'_fields.3',[]);
          record._fields[3].forEach(function(organization) {
            tempObj.organisation = organization.properties.term;
          });
          objectPath.ensureExists(record,'_fields.2',[])
          record._fields[2].forEach(function(location) {
            tempObj.location = location.properties.term;
          });
          results.push(tempObj);
        });
        res.json(results);
      })
    },function(err) {
      res.status(500).send(err);
    });
});

module.exports = router;
