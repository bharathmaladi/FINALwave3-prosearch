var express = require('express');
var router = express.Router();
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.20", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var underscore = require('underscore');

var all_node=[];
var link_data=[];
var searchText=function(i,result)
{
	var node={};
	var nodes1={};
	var link={};
	link['source']=result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].start.properties.name;
	link['target']=result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].end.properties.name;
	link['relation']=result.records[i]._fields[0].segments[result.records[i]._fields[0].segments.length-1].relationship.type;

	all_node.push(link['source']);
	all_node.push(link['target']);
	link_data.push(link);

};

router.get('/searched_links/:node_name/:hopcount', function(req, res) {

		var val=req.params.node_name;
		var h=req.params.hopcount;

	session.run( "MATCH p=(n:skills)-[r*.."+h+"]-(result:skills) WHERE n.name='" + val +  "' RETURN p")


		  .then( function(result) {
				link_data=[];
				for(var i=0;i<result.records.length;i++)
				{
				searchText(i,result);
				}

				res.send(link_data);
	  }).catch (function(err){
			console.log(err);
		})
});//end Get the links for searched text end



							//<-----To get the nodes for the searched text------>
var uniqnode=[];
var uniqnodefn=function(i,uniq_node)
{	//node3=[];
	uniqnode.push({"id":uniq_node[i],"group":1});
};

router.get('/searched_nodes/:node_name/:hopcount', function(req, res) {
link_data=[];var uniq_node=[];
    var value=req.params.node_name;
    var h = req.params.hopcount;
    session.run( "MATCH p=(n:skills)-[r*.."+h+"]-(result:skills) WHERE n.name='" + value +  "' RETURN p")
        .then( function(result) {
                    if(result.records=="")
                    {
                        session.run( "MATCH (n:skills{name:'"+value+"'}) RETURN n")
                          .then( function( result ) {
                                    console.log(result.records[0]._fields[0].properties);
                                    var single_node=[];
                                    single_node.push({"id":result.records[0]._fields[0].properties.name,"group":1});
                                    res.send(single_node);
                            })
                    }
else{
            link_data=[];uniqnode=[];all_node=[];
        for(var i=0;i<result.records.length;i++)
            {
                searchText(i,result);
            }
            uniq_node=underscore.uniq(all_node);
            for(var i=0;i<uniq_node.length;i++)
            {
                uniqnodefn(i,uniq_node);
            }
            res.send(uniqnode);
        }
})
});//end get the nodes for the searched text


module.exports = router;
