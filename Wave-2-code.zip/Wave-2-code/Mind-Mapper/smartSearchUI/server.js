//-------- Variables ---------->
var express = require('express');
var app = express();
var path = require('path');
var mongodb = require('mongodb');
var mongoClient = mongodb.MongoClient;
var url = 'mongodb://10.219.85.122/Portfolio-Management';
var bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


var deletequery = require('./routes/deletequery_api');
var getquery = require('./routes/getquery_api');
var relation = require('./routes/relation_api');
var savequery = require('./routes/savequery_api');
var searchresults = require('./routes/searchresults_api');
var validate = require('./routes/validatequery_api');
var graph = require('./routes/graph_api');

//-------- Set Port ---------->
app.set('port', process.env.PORT || 8080);

//-------- Set Path ---------->
app.use(express.static(__dirname + '/public'));

//-------- Index Route ---------->
app.get('/', function(req,res){
  res.sendFile(path.join(__dirname+'/public/index.html'));
});

mongoClient.connect(url, function(err, database) {
 if(err) throw err;
 db = database;
 app.listen(app.get('port'));
 console.log('Server Started');
});

//-------- APIs ---------->
app.use('/api',deletequery);
app.use('/api',getquery);
app.use('/api',relation);
app.use('/api',savequery);
app.use('/api',searchresults);
app.use('/api',validate);
app.use('/api',graph);

app.get('*', function(req, res, next) {
 var err = new Error();
 err.status = 404;
 next(err);
});
// handling 404 errors
app.use(function(err, req, res, next) {
 if(err.status !== 404) {
   return next();
 }
 res.sendFile(path.join(__dirname+'/public/404.html'));
});

module.exports = app;
