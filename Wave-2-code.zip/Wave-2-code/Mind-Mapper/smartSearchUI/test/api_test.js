var request = require('supertest');
var app = require('../server.js');
var mongoClient = require('mongodb').MongoClient;

beforeEach(function(done) {
   var url = 'mongodb://10.219.85.96/Portfolio-Management';
   mongoClient.connect(url, function(err, database) {
       console.log("INSIDE MONGO CONNECT");
       if(err) {
           console.log("Unable to connect -failed to cvonnect to required url");
       }
       else {
           db = database;
           console.log('Server Started');
       }
       done();
   });
});

describe('queryapi',function() {
   this.timeout(15000);
  it('should return a set of query', function(done) {
    request(app)
       .get('/api/query')
      .end(function(err,res) {
        console.log(res.body);
        done();
      });
  });

it('should return a set of neo4j relations queries', function(done) {
   this.timeout(15000);
 request(app)
    .get('/api/relations')
   .end(function(err,res) {
       if (err) return done(err);
     console.log(res.body);
     done();
   });
});
});
