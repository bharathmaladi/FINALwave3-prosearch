angular.module('keywordsDirective', ['ngMaterial'])

.controller('keywordCtrl', function($scope,$http,$mdDialog) {

  $scope.relations = [
          "subconceptof",
          "exampleof",
          "related"
      ];
  $scope.properties=[
        "DoorNo",
        "Street",
        "PinCode"
      ]
  // $http.get('http://localhost:9050/relations').success(function(data){
  //   $scope.relations=data;
  // });
  $http.get('http://localhost:9000/keywords').success(function(data){
    $scope.data=data;
    $scope.count=0;
    $scope.todos=[];
    for(var k=0;k<$scope.data.length;k++){
      for(var l=0;l<$scope.todos.length;l++){
        if($scope.data[k].keyword==$scope.todos[l].keyword){
         var found=true;
        break;
        }
        else{
         found=false;
        }
      }
      if(!found){
        var obj={};
        obj.keyword=$scope.data[k].keyword;
        obj.count=1;
        $scope.todos.push(obj);
      }
      else{
           for(var z=0;z<$scope.todos.length;z++){
             if($scope.todos[z].keyword==$scope.data[k].keyword){
               $scope.todos[z].count++;
             }
           }
      }

    }

     $scope.selected = [];
     $scope.toggle = function (item, list) {
       var idx = list.indexOf(item);
       var ind=$scope.todos.indexOf(item);
       if (idx > -1) {
         list.splice(idx, 1);
        //  $scope.todos.value[ind]!=$scope.item.value[ind];
       }
       else {
         list.push(item);
          // $scope.todos.value[ind]!=$scope.item.value[ind];
       }
     };

     $scope.exists = function (item, list) {
       return list.indexOf(item) > -1;
     };

     $scope.isIndeterminate = function() {
       return ($scope.selected.length !== 0 &&
           $scope.selected.length !== $scope.todos.length);
     };

     $scope.isChecked = function() {
       return $scope.selected.length === $scope.todos.length;
     };

     $scope.toggleAll = function() {
       if ($scope.selected.length === $scope.todos.length) {
         $scope.selected = [];
       } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
         $scope.selected = $scope.todos.slice(0);
       }
     };
});

$scope.showTabDialog=function(eve,keywords){

   templateUrl:'includes/views/query.html'
};
 $scope.query=function(eve,keyword){
  key=keyword;
  // getQuery();
  $mdDialog.show({
    controller:  'DialogController',
    templateUrl: 'includes/views/query.html',
    parent: angular.element(document.body),
    targetEvent: eve,
    clickOutsideToClose: true
})};

$scope.deletefun = function(ev,word) {
  console.log(word);
$mdDialog.show({
controller:  'DialogController',
templateUrl: 'includes/views/delete.html',
parent: angular.element(document.body),
targetEvent: ev,

clickOutsideToClose: true
})};

// $scope.addNodes=function(arr_values){
// return $scope.forms=arr_values;
// };
})

.controller('DialogController',function($scope,$mdDialog,$rootScope,$http){
// $scope.getQery=function(){
var queObj=[];
  $http.get('http://localhost:9000/keywords').success(function(data) {
       $scope.que_data=data;
      for(var i=0;i<$scope.que_data.length;i++){
          if($scope.que_data[i].keyword==key){
             $scope.obj={};
             $scope.obj.query=$scope.que_data[i].query;
             queObj.push($scope.obj);
        }
    }
  });
  $scope.list=queObj;
// };
})


.directive('addKeywords', function() {
  return {
    templateUrl: 'directives/keyword.directive.html'
  };
});
