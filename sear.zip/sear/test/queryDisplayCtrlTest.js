describe('queryDisplay', function() {
  var injector;
  var element;
  var scope;

  beforeEach(function() {
    injector = angular.injector(['keywordsDirective']);
    injector.invoke(function($rootScope, $compile) {
      scope = $rootScope.$new();
      element = $compile('  <add-keywords></add-keywords>')(scope);
      scope.$apply();
    });
  });
  it('Initial display', function(done) {
    scope.$on('queryDisplayCtrl', function() {
      expect($scope.display).to.equal("i want who are all in ece department");
    });
  });
});
