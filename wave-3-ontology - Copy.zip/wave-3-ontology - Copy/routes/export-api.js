var express = require('express');
var router = express.Router();
var fs = require('fs');
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.85.69",neo4j.auth.basic("neo4j", "password"));
var session = driver.session();
var path = require('path');

router.get('/export',function(req,res){
  console.log("inside Export Api");
  var records=0;
  var noRel=0;
  var count=0;
  var fd = fs.openSync("./exports/Export.json",'w+');
  fs.appendFile(fd,"["+"\n",function(err){
    if (err) {
      console.log("inside append of [");
      console.log(err);
    }
    else{
      // console.log("File Appending [");
    }
  });

  var promiseOfNodesWithRelations = new Promise(function(resolve,reject) {
    session.run("MATCH (n)-[r]->(m) RETURN DISTINCT  n,r,m")
    .subscribe({
      //========================== Nodes with relations ======================================
      onNext: function (record) {
        var obj={};
        var obj1={};
        var source = record.get('n');
        obj1.labels = source.labels;
        obj1.properties = source.properties;
        obj.source = obj1;                                     // Source Node
        obj1={};
        var relation = record.get('r');
        obj1.type = relation.type;
        obj1.properties = relation.properties;
        obj.relation = obj1;                                // Relationship Between Source and Target Nodes
        obj1={};
        var target = record.get('m')
        obj1.labels = target.labels;
        obj1.properties = target.properties;
        obj.target = obj1;                               // Target Node
        records++;                                      // Count of recods with relations processed
        fs.appendFile(fd,JSON.stringify(obj)+","+"\n");
                    // console.log("Record Appended");
      },
      onCompleted: function (result) {
        console.log("completed with relatuions");
        // console.log(result.ResultSummary.StatementStatistics._stats);
        resolve();
      },
      onError: function (error) {
        console.log("inside n-r-m");
        console.log(error);
        reject(error);
      }
    });
  });

  var promiseOfNodesWithoutRelations = new Promise(function(resolve,reject) {
    session.run("MATCH (n) WHERE NOT (n)--() RETURN n")
    .subscribe(
      {
        onNext: function (record) {
          var obj={};
          var obj1={};
          var source = record.get('n');
          if (source.labels.length != 0 && source.properties.length !=0) {
            obj1.labels = source.labels;
            obj1.properties = source.properties;
            obj.source = obj1;
            fs.appendFile(fd,JSON.stringify(obj)+","+"\n");
            noRel++;
          }
          else {
            count++;
          }
        },
        onCompleted: function (result) {
          // console.log("Completed without relations");
          resolve();
        },
        onError: function (error) {
          console.log("inside n ");
          console.log(error);
          reject();
        }
      });
    });

    Promise.all([promiseOfNodesWithRelations,promiseOfNodesWithoutRelations]).then(function() {
      // console.log("Inside Promise ALL");
      session.close();
      fs.appendFileSync(fd,"{}"+"]");
      console.log("==================== Exported Completed =======================");
      console.log("No.of Records Containing Relations Processed is : " + records);
      console.log("No.Of Records Without Relations Processed is : "+ noRel);
      console.log("No.Of Empty Nodes Found and Rejected : " + count);
      console.log(fd);
      fs.close(fd,function(err) {
        console.log("Error closing the fd")
        console.log(err);
      });
      try {
        var filePath = path.join(__dirname,"../exports/Export.json");
        // console.log(filePath);
        res.download(filePath);
      } catch (err) {
        console.log("error in sending File");
        console.log(err);
      }
    }, function(err) {
      console.log("error in resolving all promises");
      console.log(err);
    });
  });

  module.exports = router;
