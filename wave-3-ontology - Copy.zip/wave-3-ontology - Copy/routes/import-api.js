var express = require('express');
var router = express.Router();
var jsonStream = require('JSONStream');
var formidable = require('formidable');
var highland = require('highland');
var _=require('underscore');
var fs = require("fs");
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.21:7687",neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();

router.post('/upload',function(req,res) {
  var form = new formidable.IncomingForm();
  form.uploadDir = "./uploads";
  form.keepExtensions = true;
  form.parse(req, function(err, fields, files) {
    var file=files.upload.path;
    var x=file.split('.').pop();
    var contents = [];
    var empty = 0;
    var nodesWithRelations = 0;
    var nodesWithoutRelations = 0;
    var noOfNodesProcessed = 0;
    var stats = {};
    stats.nodesCreated = 0 ;
    stats.relationshipsCreated = 0;
    stats.propertiesSet = 0;
    stats.labelsAdded = 0;
    stats.nodesWithRelations = 0;
    stats.nodesWithoutRelations = 0;
    stats.emptyNodes = 0;
    stats.noOfNodesProcessed = 0;
     var promises = [];
    if(x=="json") {
      var jsonDataStream = fs.createReadStream(file);
      highland(jsonDataStream.pipe(jsonStream.parse('*'))).each(function(keyword) {
        var sourceLables = "";
        var targetLables = "";
        var relationLables = "";
        if(_.isEmpty(keyword)) {
          empty++;
          stats.emptyNodes++;
        }
        else if(keyword.target != undefined){
          var source_props = keyword.source.properties;
          var target_props = keyword.target.properties;
          var relation_props = keyword.relation.properties;

          for (var i = 0; i < keyword.source.labels.length; i++) {
            sourceLables=sourceLables+":"+keyword.source.labels[i];
          }

          for (var i = 0; i < keyword.target.labels.length; i++) {
            targetLables=targetLables+":"+keyword.target.labels[i];
          }

          var promiseOfNodesWithRelations = new Promise(function(resolve,reject) {
            var query = 'MERGE (s'+sourceLables+' {name:"'+source_props.name+'"}) ON CREATE SET s={source} ON MATCH SET s+={source} MERGE (t'+targetLables+' {name:"'+target_props.name+'"}) ON CREATE SET t={target} ON MATCH SET t+={target} MERGE (s)-[r:'+keyword.relation.type+']->(t) ON CREATE SET r={relation} ON MATCH SET r+={relation} return s,t,r;';
            session.run(query,{source:source_props,target:target_props,relation:relation_props})
            .then(function(result)
            {
              stats.nodesCreated += result.summary.updateStatistics._stats.nodesCreated;
              stats.relationshipsCreated += result.summary.updateStatistics._stats.relationshipsCreated;
              stats.propertiesSet += result.summary.updateStatistics._stats.propertiesSet;
              stats.labelsAdded += result.summary.updateStatistics._stats.labelsAdded;
              stats.nodesWithRelations++;
              noOfNodesProcessed++;
              nodesWithRelations++;
              resolve();
            })
            .catch(function(err)
            {
              console.log("query",query);console.log(err);
              reject();
            });
          });
          promises.push(promiseOfNodesWithRelations);
        }
        else {
          var source_props = keyword.source.properties;

          for (var i = 0; i < keyword.source.labels.length; i++) {
            sourceLables=sourceLables+":"+keyword.source.labels[i];
          }
          var promiseOfNodesWithoutRelations = new Promise(function(resolve,reject) {
            var query = 'MERGE (s'+sourceLables+' {name:"'+source_props.name+'"}) ON CREATE SET s={source} ON MATCH SET s+={source} return s;';

            session.run(query,{source:source_props})
            .then(function(result)
            {
              stats.nodesCreated += result.summary.updateStatistics._stats.nodesCreated;
              stats.relationshipsCreated += result.summary.updateStatistics._stats.relationshipsCreated;
              stats.propertiesSet += result.summary.updateStatistics._stats.propertiesSet;
              stats.labelsAdded += result.summary.updateStatistics._stats.labelsAdded;
              stats.nodesWithoutRelations++;
              nodesWithoutRelations++;
              noOfNodesProcessed++;
              resolve();
            })
            .catch(function(err) {
              reject(err);
              console.log("query",query);
              console.log(err);
            });
            });
            promises.push(promiseOfNodesWithoutRelations);
          }
        }).done(function() {
          Promise.all(promises).then(function() {
            console.log("================== Import Statistics =======================");
            console.log("No.of Nodes Processed: " + noOfNodesProcessed );
            console.log("No.of Nodes With Relations Processed: " + nodesWithRelations);
            console.log("No.of Nodes Without Relations Processed: " + nodesWithoutRelations );
            console.log("Count of Empty Objects Rejected: " + empty);
            stats.noOfNodesProcessed = (stats.nodesWithRelations * 2) + stats.nodesWithoutRelations;
            console.log(stats);
            res.send(stats);
          });
        })

      }
      else {
        res.end('Please select json file');
      }
    });
  });
  module.exports = router;
