var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.21", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();
var prop = {type: 'Front End Programming',alsoKnownAs: 'ReactJS'};
var query = 'MERGE (x:skills {term: "react"}) ON CREATE SET x={prop} ON MATCH SET x+={prop} return x';

session.run(query,{prop:prop}).then(function(result){console.log(result);}).catch(function(err){console.log(err);});
MERGE (s:'+keyword.source.label+')
ON CREATE SET s={source}
ON MATCH SET s+={source}
MERGE (t:'+keyword.target.label+')
ON CREATE SET t={target}
ON MATCH SET t+={target}
MERGE (s)-[r:'+keyword.relation.type+']->(t)
ON CREATE SET r={relation}
ON MATCH SET r+={relation} return s,t,r;
// var target =  return n;
