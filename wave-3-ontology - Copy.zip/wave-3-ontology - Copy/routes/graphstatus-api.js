var express = require('express');
var router = express.Router();
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.21:7687", neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();

router.get('/getcount',function(req,res) {
  var labels,nodes,keys,nodecount;
  var relationcount,avgPropertyCount,minPropertyCount,avgRelationshipCount,minRelationshipCount,maxRelationshipCount,sampleSize,source,propertiesOfSource,via,target,propertiesOfTarget,frequency;
  var nodeProperties={},prop={},relationProperties={},kindOfRelations={},kindOfNodes={},result={};
  var node=[],relations=[],promises = [];
  var countOfNodes = new Promise(function(resolve,reject) {
    session.run("MATCH (n) RETURN count(n) ")
    .subscribe(
      {
        onNext: function (record) {
          nodes = record.get(('count(n)'));

        },
        onCompleted: function () {
          resolve(nodes);
        },
        onError: function (error) {
          reject(error);
        }
      });
  });
  promises.push(countOfNodes);
  var countOfNodeProperties = new Promise(function(resolve,reject) {
    var keys;
    session.run("match (n) return count(keys(n)) ")
        .subscribe({
                    onNext: function (record) {
                      keys = record.get(('count(keys(n))'));
                    },
                    onCompleted: function () {
                      resolve(keys);
                    },
                    onError: function (error) {
                      reject(error);
                    }
                  });
    });
  promises.push(countOfNodeProperties);
  var countOfRelations = new Promise(function(resolve,reject) {
    session.run("MATCH ()-->() RETURN count(*) ")
        .subscribe(
            {
                onNext: function (record)
                 {
                  relation = record.get(('count(*)'));
                 },
                onCompleted: function ()
                 {
                   resolve(relation);
                 },
                onError: function (error) {
                  reject(error);
                }
         });

  });
  promises.push(countOfRelations);
  var kindOfNodes = new Promise(function(resolve,reject) {
    var labels = [];
    session.run(" MATCH (n) RETURN DISTINCT labels(n),count(*) AS SampleSize,avg(size(keys(n))) as Avg_PropertyCount,min(size(keys(n))) as Min_PropertyCount,max(size(keys(n))) as Max_PropertyCount,avg(size( (n)-[]-() ) ) as Avg_RelationshipCount,min(size( (n)-[]-() ) ) as Min_RelationshipCount,max(size( (n)-[]-() ) ) as Max_RelationshipCount ")
        .subscribe(
            {
                onNext: function (record) {
                 var labels = record.get('labels(n)');
                 var sampleSize = record.get('SampleSize');
                 var avgPropertycount = record.get('Avg_PropertyCount');
                 var minPropertyCount = record.get('Min_PropertyCount');
                 var maxPropertyCount = record.get('Max_PropertyCount');
                 var avgRelationshipCount = record.get('Avg_RelationshipCount');
                 var minRelationshipCount = record.get('Min_RelationshipCount');
                 var maxRelationshipCount = record.get('Max_RelationshipCount');
                 var nodeProperties = {"kindOfNodes":sampleSize.toString(),"avgPropertyCount":avgPropertycount.toString(),"minPropertyCount":minPropertyCount.toString(),"maxPropertyCount":maxPropertyCount.toString(),"avgRelationshipCount":avgRelationshipCount .toString(),"minRelationshipCount":minRelationshipCount.toString(),"maxRelationshipCount":maxRelationshipCount.toString()};
                 var kindOfNode = {"sourceLabels":labels,"nodeProperties":nodeProperties};
                 node.push(kindOfNode);
               },
               onCompleted: function () {
                 resolve(node);
               },
                onError: function (error) {
                  reject(error);
                }
            });

  });
  promises.push(kindOfNodes);
  var kindOfRelation = new Promise(function(resolve,reject) {
    session.run("MATCH (n) MATCH (n)-[r]->(m) WITH n, type(r) as via, m RETURN labels(n) as from,reduce(keys = [], keys_n in collect(keys(n)) | keys + filter(k in keys_n WHERE NOT k IN keys)) as props_from,via,labels(m) as to,reduce(keys = [], keys_m in collect(keys(m)) | keys + filter(k in keys_m WHERE NOT k IN keys)) as props_to,count(*) as freq")
        .subscribe(
            {
                onNext: function (record) {
                 source= record.get('from');
                 propertiesOfSource=record.get('props_from')
                 relation=record.get('via');
                 target=record.get('to');
                 propertiesOfTarget=record.get('props_to');
                 frequency=record.get('freq');
                 kindOfRelations={"sourceLabels":source,"sourceProperties":propertiesOfSource,"relation":relation,"targetLabels":target,"propertiesOfTarget":propertiesOfTarget,"frequency":frequency.toString()};
                 relations.push(kindOfRelations);
               },
                 onCompleted: function () {
                   resolve(relations);
                },
                onError: function (error) {
                  reject(error);
                }
            });
          });
  promises.push(kindOfRelation);
  Promise.all(promises).then(function(data) {
  var result = {"nodes":data[0].toString(),"keys":data[1].toString(),"relation":data[2].toString(),"kindsOfNodes":data[3],"kindOfRelation":data[4]};
    res.json(result);
}, function(err) {
    console.log(err);
  });

});

module.exports = router;
