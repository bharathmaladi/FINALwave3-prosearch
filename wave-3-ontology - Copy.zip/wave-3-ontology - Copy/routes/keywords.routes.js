var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var mongoClient = require('mongodb').MongoClient;
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://10.219.85.69/ontology-keywords';
var app = express();
var db;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());


mongoClient.connect(url, function(err, database) {
  if(err) {
    console.log('Unable to connect to the OntologyKeywords mongoDB server--Failed to find  Requested Url');
  }
  else {
    db = database;
    console.log('OntologyKeywords Server Started');
  }
  // db.close();
});

// returns list of all the keywords to the client
router.get('/getKeywords', function(req, res) {
  // var db = req.app.locals.db;
  var items = db.collection('keywords').find().toArray(function(err, items) {
    if (err) throw err;
    else {
      res.send(items);
    }
  });
});

router.post('/deleteKeyword',function(req,res){
            // var db = req.app.locals.db;
             var id = req.body.id;
             console.log(id);
             var response=db.collection('keywords').deleteOne({"_id":ObjectId(id)});
            //  res.send("keyword Deleted");
            res.send(response)
   });
//
//


module.exports = router;
