var mindMap = angular.module('mindMap',['ngMaterial','ui.router']);

mindMap.controller('mainCtrl', function ($scope, $timeout, $mdSidenav) {
  $scope.toggleLeft = buildToggler('left');
  function buildToggler(componentId) {
    return function() {
      $mdSidenav(componentId).toggle();
    }
  }
});

mindMap.directive('graphDirective',function(){
  return {
    templateUrl : 'views/graph.html',
    controller : 'DialogController'
  };
});


mindMap.directive('termDirective',function(){
  return {
    templateUrl : 'views/term.html'
  };
});

mindMap.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('ontologyGraph', {
            url: '/',
            templateUrl: 'views/ontologyGraph/ontologyGraph.html'
        })

        .state('keyWords',{
          url:'/keywords',
          templateUrl: 'views/ontologyKeywords/ontologyKeywords.html'
        })

        .state('bulkUpload',{
          url:'/bulkUpload',
          templateUrl: 'views/ontologyBulkUpload/ontologyBulkUpload.html'
        })
  // $urlRouterProvider.otherwise('/');
});
