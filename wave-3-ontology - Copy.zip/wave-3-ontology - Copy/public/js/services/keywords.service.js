mindMap.service('KeywordsService',function($http){
    this.getKeywords = function(){
      return $http.get('/api/getKeywords');
    }
    this.deleteKeyword = function(id){
      return $http.post('/api/deleteKeyword',{'id':id})
    }
});
