mindMap.service('bulkOperationsservice',function($http){
    this.getcount = function(){
      return $http.get('/api/getcount');
    },
    this.export = function(){
      return $http.get('/api/export');
    }

    });
