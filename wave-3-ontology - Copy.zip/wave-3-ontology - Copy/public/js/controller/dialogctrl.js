mindMap.controller('DialogController', function($scope, $compile, $mdDialog, $rootScope, DeleteNodeService, EditNodeService, GetNodeService,GetNameService,PostNodeService,GetNodeService) {
  $scope.searchText = "";
  $scope.check = true;
  $scope.prop_key_array = [];
  $scope.searchText_T = "";
  $scope.a =0;
  $scope.text="";
  $scope.text_T="";
  $scope.object={};
  $scope.newobject={};
  $rootScope.editobject={};
  $rootScope.edit_properties = ['init','intit'];
  $scope.selectedItem = [];
  $scope.selectedItem_T = [];
  $scope.isDisabled = false;
  $scope.isDisabled_T = false;
  $scope.noCache = false;
  $scope.noCache_T = false;
  $scope.show = false;
  $scope.show1 = false;
  $scope.showsearch=false;
  $scope.i=-1;
  $scope.flag=0;
  $scope.index=[];
  $scope.filter_show = true;
  $scope.data1 = {};
  $scope.data = {};

  PostNodeService.getRelation()
             .success(function (data, status, headers, config) {
                $scope.relations = data;
           });
 PostNodeService.getLabel()
            .success(function (data, status, headers, config) {
               $scope.labels = data;
            });



$scope.add_more_prop = function(key,value){
$scope.object[key]=value;
$scope.property_key   = " ";
$scope.property_value = " ";
}
$scope.add_new_prop = function(key,value){
$scope.newobject[key]=value;
$scope.new_property_key   = " ";
$scope.new_property_value = " ";
}
$scope.add_edit_prop = function(key,value){
$rootScope.editobject[key]=value;
$scope.add_key_edit   = " ";
$scope.add_value_edit = " ";
}
$scope.selectedItemChange = function (item) {
      if ($scope.selectedItem)
        $scope.text=$scope.selectedItem.name;
}
      $scope.searchTextChange = function (str) {
          return GetNameService.getName(str);
      }
      $scope.selectedItemChange_T = function (item) {
          if ($scope.selectedItem_T)
            $scope.text_T=$scope.selectedItem_T.name;
    }
      $scope.searchTextChange_T = function (str) {
          return GetNameService.getName(str);
      }
      $scope.selectedItemChange_D = function (item) {
          if ($scope.selectedItem_D){
            $scope.text_D=$scope.selectedItem_D.name;
            $scope.flag=1;
          }
        }
      $scope.searchTextChange_D = function (str) {
          return GetNameService.getName(str);
      }

    $scope.hide = function() {
      $mdDialog.hide();
    };
    $scope.cancel = function() {
      $mdDialog.cancel();
    };
    $scope.answer = function(src,tar,rel,label,flag,id) {
      var sendingObj = {
      src:src.toLowerCase(),tar:tar.toLowerCase(),rel:rel,label:label,flag:flag, key_object:$scope.newobject
    };
      $rootScope.$broadcast("capture",sendingObj,id);
      $mdDialog.cancel();
        // document.getElementById(tar).className="strike";
    };

    $scope.newNode = function(src,tar,rel,label) {
    $rootScope.$broadcast("newNode_capture", {
      src:src.toLowerCase(),tar:tar.toLowerCase(),rel:rel,label:label,properties:$scope.object
      })
      $mdDialog.cancel();
    };

    // delete function
    $scope.del_fun = function(del) {
        $rootScope.$broadcast("del_capture", {
      del : del.name
    })
      $mdDialog.cancel();
    };
    //swap function
      $scope.swap = function(s_label,o_label){
        $scope.sub_label = o_label;
        $scope.obj_label = s_label;
      };
      $scope.swap1 = function(s_label,o_label,rel){
        $scope.sub1 = o_label;
        $scope.obj1 = s_label;
      };

      $scope.$on("link_broadcast",function(event,args){
          $scope.sub_edit = "Enter Value..";
          $scope.add_edit=false;
          $scope.edit_prop_btn = true;
          $scope.add_prop_btn = false;
          $scope.keys = [];
          var s = "";
          var k = [];
          var v = [];
          var count = 0;
          var unique = 0;
          var unique1 = 0;
          var input,input1;
          var whole_edit_key = [];
          var whole_edit_value = [];
          var key_value = {};
          $scope.del_src = args.obj;
          $scope.sub_edit = args.obj_rel;
          GetNodeService.getRelationProp(args.obj,args.obj_rel).
          success(function(data){
            document.getElementById('key_card').innerHTML = "";
            document.getElementById('value_card').innerHTML = "";
            var obj=args.obj;
            k = Object.keys(data);
            $scope.keys = k;
            for(i=0;i<k.length;i++){
              v[i] = data[k[i]];
              input = document.createElement('input');
              input.type = "text";
              input.size = "10";
              input.value = k[i];
              input.id = 'edit_key_id'+ ++unique;
              key_card.appendChild(input);

             input1 = document.createElement('input');
                input1.type = "text";
                input1.value = v[i];
                input1.id = 'edit_value_id'+ ++unique1;
                input1.size = 10;
                value_card.appendChild(input1);
            }


            $scope.edit_func = function(){
                  for(var i=1;i<=k.length;i++){
                      whole_edit_key.push(document.getElementById("edit_key_id"+i).value);
                      whole_edit_value.push(document.getElementById("edit_value_id"+i).value);
                      }
            for (var i = 0; i < whole_edit_key.length; i++) {
              key_value[whole_edit_key[i]] = whole_edit_value[i];
            }
            EditNodeService.editNodes(whole_edit_key,  whole_edit_value, args.obj).success(function(data){
            })
            window.alert("Properties edited successfully");
            window.location.reload();
          }
          $scope.editdeletefun = function(key){
            var c=confirm("Sure you want to delete ??");
            DeleteNodeService.deleteKeys(key, obj).success(function(data){
            })
            window.location.reload();

            }

    })
    $scope.edit_add_func = function(key){
      $scope.add_edit=true;
      $scope.edit_prop_btn = false;
      $scope.add_prop_btn = true;
    }
    $scope.add_all = function(){
      var objstr=JSON.stringify($rootScope.editobject);
      PostNodeService.addProperty(args.obj,args.obj_rel,args.obj_tar,objstr).success(function(data){

      })
      alert("properties added successfully");
      window.location.reload();
    }
  });


});
