angular.module('mindMap')
   .directive('existingNode',function() {
     return{
       templateUrl: 'directives/existingNode/existingNode.template.html',
       controller:'DialogController'
     }
   });
