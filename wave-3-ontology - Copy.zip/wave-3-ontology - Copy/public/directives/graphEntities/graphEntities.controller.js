angular.module('mindMap').controller('EntitiesCtrl',function($scope,$http,$mdDialog,bulkOperationsservice) {
  $scope.items =  [
    { name: 'Node', img: 'images/node.jpg'},
    { name: 'Node Properties', img: 'images/nodeProperties.jpg'},
    { name: 'Relation', img: 'images/relation.jpg'},
    {name:'Relation Properties',img:'images/relationProperties.jpg'}
  ];

  $scope.showStatistics = function(ev) {
      $mdDialog.show({
        templateUrl: 'views/ontologyBulkUpload/Statistics.html',
        parent: angular.element(document.body),
        targetEvent: ev,
        fullscreen: $scope.customFullscreen // Only for -xs, -sm breakpoints.
      })
    };

 $scope.selected = $scope.items;
 $scope.toggle = function (item, list) {
   var idx = list.indexOf(item);
   var index = $scope.selected.indexOf(item);
   if (idx > -1) {
     list.splice(idx, 1);
   }
   else {
         list.push(item);
   }
 };

 $scope.exists = function (item, list) {
return list.indexOf(item) > -1;
 };
 $scope.isIndeterminate = function() {
   return ($scope.selected.length !== 0 &&
       $scope.selected.length !== $scope.items.length);
 };
 $scope.isChecked = function() {
   return $scope.selected.length === $scope.items.length;
 };
 $scope.toggleAll = function() {
   if ($scope.selected.length === $scope.items.length) {
     $scope.selected = [];
   } else if ($scope.selected.length === 0 || $scope.selected.length > 0) {
     $scope.selected = $scope.items.slice(0);
   }
 };
  $scope.checkFile=function() {
     var fileElement = document.getElementById("uploadFile");
     var file = fileElement.files[0];
          var fileExtension = "";
     if (fileElement.value.lastIndexOf(".") > 0) {
         fileExtension = fileElement.value.substring(fileElement.value.lastIndexOf(".") + 1, fileElement.value.length);
     }
     var data = {};
      var fd = new FormData();
        fd.append("upload",file,file.name);
       data.fileVal = fileElement.value;
     if (fileExtension.toLowerCase() == "json") {
        var a=$http.post('/api/upload',fd,{
          transformRequest: angular.identity,
          headers: {
            "Content-Type":  undefined
          }});
       a.success(function(stats)
       {
         console.log(stats);
         alert("File Uploaded Successfully");
       });


     }
     else {
         alert("You must select a JSON file for upload");
         return false;
     }
 }

// $scope.export = function() {
//    var response  = bulkOperationsservice.export();
//    response.success(function(data){
//      alert("Exported Successfully")
//      console.log("export Successfull");
//      console.log(data);
//    })
// };

 $scope.showAdvanced = function(ev) {
    $mdDialog.show({
      templateUrl: 'views/ontologyBulkUpload/Uploadform.html',
      parent: angular.element(document.body),
      targetEvent: ev,
      clickOutsideToClose:false,
      fullscreen: $scope.customFullscreen
    })
  };
  $scope.close = function(ev){
    $mdDialog.hide();
  };

});
mindMap.config(function($stateProvider, $urlRouterProvider) {
    $stateProvider
    .state('Graphstatus', {
        url: '/graphstatus',
        templateUrl: 'views/ontologyBulkUpload/Graphstatus.html'
    })

$urlRouterProvider.otherwise('/');
});
