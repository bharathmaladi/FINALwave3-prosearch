angular.module('mindMap')
.directive('graphEntities',function(){
  return {
    templateUrl: 'directives/graphEntities/graphEntities.template.html',
    controller: "EntitiesCtrl"
  }
})
