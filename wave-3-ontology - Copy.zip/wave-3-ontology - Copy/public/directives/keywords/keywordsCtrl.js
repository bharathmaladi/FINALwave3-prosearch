mindMap.controller('keywordsCtrl', function($scope,$http,$mdDialog,KeywordsService,GetNodeService,PostNodeService) {

   var keywords=KeywordsService.getKeywords();
   keywords.success(function(data){
    //  console.log(data);
     $scope.todos=data;
   });

   $scope.addshows=function(keyword,label,id){
    $scope.addshow=true;
    $scope.keyword=keyword;
    $scope.exLabel=label;
    $scope.term_id=id;
  };

  $scope.close=function(){
    $scope.addshow=false;
  };

//INJECT THE DISPLAYING QUERY FILE

$scope.query=function(eve,keyword,id){
 $mdDialog.show({
   controller:  QueryController,
   templateUrl: 'views/ontologyKeywords/query.html',
   parent: angular.element(document.body),
   targetEvent: eve,
   clickOutsideToClose: true,
   resolve: {
     keywords: function() {
       return $scope.todos;
     },
     keyword: function() {
       return keyword;
     },
     keywordID: function() {
       return id;
     }
   }
 })
};


$scope.deletefun = function(keyword,id){
  // console.log("inside deletefun");
  // console.log(id);
    KeywordsService.deleteKeyword(id).success(function(){
      document.getElementById(keyword).className="strike";
       window.location.reload();
    });
   };

$scope.showConfirm = function(ev,keyword,id) {
   var confirm = $mdDialog.confirm()
         .title('Are you sure to delete '+ keyword +' from the list')
         .targetEvent(ev)
         .ok('Yes')
         .cancel('No');

   $mdDialog.show(confirm).then(function() {
    //  console.log("inside yes");
      $scope.deletefun(keyword,id);

   }, function() {
    //  console.log("inside No");
       $mdDialog.cancel();
   });
 };




GetNodeService.getNodes()
          .success(function (data, status, headers, config) {
             $scope.data.nodes = data;
        });

$scope.$on("capture",function(event,args,id){
var obj = {};

  $scope.flag=0;
  var target=args.tar;
  if( ($scope.data.nodes.indexOf(target) )>=0){

    GetNodeService.getRelationName(args.src, args.tar, args.label).success(function(data){
      $scope.rel=data;
      if($scope.rel!="null"){
          if($scope.rel==args.rel){
              $scope.flag=2;
              obj['source']=args.src;obj['target']=args.tar;
              obj['label']=args.label;obj['relation']=args.rel;
              obj['flag']=$scope.flag;obj['properties']=args.key_object;
              var objstr=JSON.stringify(obj);
              PostNodeService.postNodes(objstr)
              .success(function(data, status, headers, config) {
                window.alert("Node added successfully");
                $scope.deletefun(args.tar,id);
                });
                  // window.location.reload();
            }
            else{
                $scope.flag=1;
                obj['source']=args.src;obj['target']=args.tar;
                obj['label']=args.label;obj['relation']=args.rel;
                obj['flag']=$scope.flag;obj['properties']=args.key_object;
                var objstr=JSON.stringify(obj);
                PostNodeService.postNodes(objstr)
                .success(function(data, status, headers, config) {
                  window.alert("Node added successfully");
                    $scope.deletefun(args.tar,id);
                  });
                    // window.location.reload();
            }
          }
          else{
              $scope.flag=1;
              obj['source']=args.src;obj['target']=args.tar;
              obj['label']=args.label;obj['relation']=args.rel;
              obj['flag']=$scope.flag;obj['properties']=args.key_object;
              var objstr=JSON.stringify(obj);
              PostNodeService.postNodes(objstr)
              .success(function(data, status, headers, config) {
                window.alert("Node added successfully");
                  $scope.deletefun(args.tar,id);
                });
                // window.location.reload();
          }
    })
}
else{
  obj['source']=args.src;obj['target']=args.tar;
  obj['label']=args.label;obj['relation']=args.rel;
  obj['flag']=$scope.flag;obj['properties']=args.key_object;
  var objstr=JSON.stringify(obj);
  PostNodeService.postNodes(objstr)
  .success(function(data, status, headers, config) {
    window.alert("Node added successfully !!");
      $scope.deletefun(args.tar,id);
    });
      // window.location.reload()
}

});

})

var QueryController = function($scope,$mdDialog,keywords,keyword,keywordID){
    for(var i=0;i<keywords.length;i++){
        if(keywords[i].keyword == keyword && keywords[i]._id == keywordID){
          $scope.queries = keywords[i].queries;
        }
    }

 $scope.cancel = function() {
       $mdDialog.cancel();
     };
};
