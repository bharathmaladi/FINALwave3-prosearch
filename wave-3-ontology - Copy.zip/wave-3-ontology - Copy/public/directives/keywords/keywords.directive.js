angular.module('mindMap')
   .directive('keywords',function(){
     return{
       templateUrl:'directives/keywords/keywords.template.html',
       controller: 'keywordsCtrl'
     }
   });
