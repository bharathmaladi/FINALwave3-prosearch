var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// set up a mongoose model
module.exports = mongoose.model('node', new Schema({
	label :String,
	sampleSize:Number,
	avgPropertycount :Number,
	 minPropertyCount :Number,
	 maxPropertyCount :Number,
	 avgRelationshipCount :Number,
	 minRelationshipCount :Number,
	maxRelationshipCount :Number
}),'NODES');
