var express 	= require('express');
var app         = express();
var bodyParser  = require('body-parser');
var morgan      = require('morgan');


var mongoose    = require('mongoose');
var jwt    = require('jsonwebtoken');

var User   = require('source');


var port = process.env.PORT || 8080;


mongoose.connect(config.database);


app.set('superSecret', config.secret);

// use body parser so we can get info from POST and/or URL parameters
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// use morgan to log requests to the console
app.use(morgan('dev'));

// =================================================================
// routes ==========================================================
// =================================================================
app.get('/getcount', function(req, res) {

	// create a sample user
	var kindOfNode = new NODES({

		labels :'Organiztion',
		sampleSize:2,
		avgPropertycount :5,
		 minPropertyCount :6,
		 maxPropertyCount :2,
		 avgRelationshipCount :3,
		 minRelationshipCount :1,
		maxRelationshipCount :5
	});
	kindOfNode.save(function(err) {
		if (err) throw err;

		console.log(' Get node values successfully');
		res.json({ success: true });
	});
});
app.use('/api', apiRoutes);

// =================================================================
// start the server ================================================
// =================================================================
app.listen(port);
console.log('Magic happens at http://localhost:' + port);

module.exports = app;
