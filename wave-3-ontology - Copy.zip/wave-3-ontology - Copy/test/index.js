var request = require('supertest');
var app = require('../server');
var chai = require('chai');
var should = chai.should();
describe('Links',function() {
  it('should return a set of links', function(done) {
    request(app)
      .get('/links')
      .end(function(err,res) {
        console.log(res.body);
        chai,should,assert,expect
        // Operation
        done();
      });
  });
});
describe('linksCheck', function() {
  it('should return error trying to retrieve diff values', function(done) {
    var link_data=[
  { value: 1, relation: 'partWhole' },
  { value: 1, relation: 'goesTogether'},
  { value: 1, relation: 'partWhole'},
  { value: 1, relation: 'goesTogether'},
  { value: 1, relation: 'partWhole'},
  { value: 1, relation: 'partWhole'},
  { value: 1, relation: 'goesTogether'},
  { value: 1, relation: 'goesTogether'} ];
  request(app)
    .get('/links')
    .end(function(err,res) {
      console.log(res.body);
      try{
        res.body.should.be.instanceOf(Array);
        link_data.forEach(function(link,index) {
          res.body[index].should.be.instanceOf(Object);
          res.body[index].should.have.property('relation');
          res.body[index].should.have.property('value');
          res.body[index].value.should.be.equal(link.value);
          res.body[index].relation.should.be.equal(link.relation);

        });
        done();
      }
      catch(e){
        done(e);
      }
      });
    });
});
