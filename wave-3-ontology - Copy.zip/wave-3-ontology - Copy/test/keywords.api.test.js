var request=require('supertest');
var should=require('should');
var app=require('../server');
var mongoclient = require('mongodb').MongoClient;
beforeEach(function(done){
  var url = 'mongodb://10.219.85.69/ontology-keywords';
  mongoclient.connect(url,function(err,database){
    console.log("Inside Mongo connect")
    if(err){
      console.log("Unable to connect the Server");
    }
    else{
      db = database;
      console.log('OntologyKeywords Server Started');
    }
    done();
  });
});

describe('getKeywords',function(){
     this.timeout(15000);
  it('should return a set of keywords',function(done){
    request(app)
    .get('/api/getKeywords')
    .expect("Content-type",/json/)
    .expect(200)
    .end(function(err,res){
      //  console.log(res);
         res.status.should.equal(200);
         console.log(res.body);

      done();
    });
  });
});
  describe('deleteKeyword',function(){
       this.timeout(15000);
    it('should return delete the keyword and return the remaining keywords',function(done){
      request(app)
      .post('/api/deletekeyword')
      .expect(200)
      .end(function(err,res){
        // console.log(res.body);
        res.status.should.equal(200);


        done();
      });
    });
  });
 //  it('should respond with JSON array', function(done) {
 //   request(app)
 //     .get('/api/getkeyworg')
 //     .expect(200)
 //     .expect('Content-Type', /json/)
 //     .end(function(err, res) {
 //       if (err) return done(err);
 //       res.body.should.be.instanceof(Array);
 //       done();
 //     });
 // });
