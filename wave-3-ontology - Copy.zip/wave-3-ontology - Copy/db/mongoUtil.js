var MongoClient = require('mongodb').MongoClient;

var _db;
var ObjectID = MongoClient.ObjectID;
module.exports = {
  connectToSmartServer: function(callback) {  
    MongoClient.connect("mongodb://10.219.85.69/smartSearchDb", function(err, db) {   
      _db1 = db;   
      return callback( err );  
    }); 
  },
  connectToKeywordServer: function(callback) {  
    MongoClient.connect("mongodb://10.219.85.69/ontology-keywords", function(err, db) {   
      _db2 = db;   
      return callback( err );  
    }); 
  },
  getSmartDb: function() {  
    return _db1;   // console.log(_db);
  },
  getKeywordsDb: function() {
    return _db2;
  }
};
