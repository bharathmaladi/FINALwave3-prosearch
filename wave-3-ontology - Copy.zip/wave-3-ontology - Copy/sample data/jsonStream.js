var jsonStream = require('JSONStream');
var fs = require('fs');
var highland = require('highland');
var _=require('underscore');
var jsonDataStream = fs.createReadStream('./Export.json');
var value=0;
highland(jsonDataStream.pipe(jsonStream.parse('*'))).each(function(keyword) {
  var label = "";
  // console.log(keyword);
  if(_.isEmpty(keyword)){
   console.log("I Got You");
  }
    else {

  for (var i = 0; i < keyword.source.labels.length; i++) {

     label=label+":"+keyword.source.labels[i];
  }
  console.log(label);
  console.log(value++);
}

});
