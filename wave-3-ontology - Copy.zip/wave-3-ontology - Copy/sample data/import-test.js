var fs = require('fs');
var neo4j = require('neo4j-driver').v1;
var driver = neo4j.driver("bolt://10.219.93.21",neo4j.auth.basic("neo4j", "1234"));
var session = driver.session();

var records=0
var fd = fs.openSync("./test.json")
fs.appendFile(fd,"["+"\n");
session.run("MATCH (n)-[r]->(m) RETURN DISTINCT  n,r,m")
   .subscribe(
       {
           onNext: function (record) {
             var obj={};
             var obj1={};
              //========================== Records with relations ======================================
              var source = record.get('n');
              obj1.labels = source.labels;
              obj1.properties = source.properties;
              obj.source = obj1;                                     // Source Node
              obj1={};
              var relation = record.get('r');
              obj1.type = relation.type;
              obj1.properties = relation.properties;
              obj.relation = obj1;                                // Relationship Between Source and Target Nodes
              obj1={};
              var target = record.get('m')
              obj1.labels = target.labels;
              obj1.properties = target.properties;
              obj.target = obj1;                               // Target Node
              records++;                                      // Count of recods with relations processed
              fs.appendFile(fd,JSON.stringify(obj)+","+"\n");
        },

           onCompleted: function () {

              //========================= Nodes WithOut Relations ==============================
               var count=0;
             session.run("MATCH (n) WHERE NOT (n)--() RETURN n")
               .subscribe(
                   {
                       onNext: function (record) {
                         var obj={};
                         var obj1={};
                          var source = record.get('n');
                         if (source.labels.length != 0 && source.properties.length !=0) {
                          obj1.labels = source.labels;
                          obj1.properties = source.properties;
                          obj.source = obj1;
                          fs.appendFile(fd,JSON.stringify(obj)+","+"\n");
                        }
                         else {
                          count++;
                         }
                    },
                       onCompleted: function () {
                         fs.appendFile(fd,"{}"+"]");
                           console.log("==================== Exported Completed ======================================");
                              console.log("No.oF Records Containing Relations Processed is : " + records);
                              console.log("No.Of Empty Nodes Found and Rejected : " + count);

                            session.close();
                       },
                       onError: function (error) {
                           console.log(error);
                       }
                    });
                    session.close();
           },
           onError: function (error) {
               console.log(error);
           }
        });
